# Lady Stalker Translation Toolkit 2.1

For **Lady Stalker English Addendum v1.2.9**. This updates the v1.2.8 translation GUI, workbook, and patch builder. No ROM is included.

An untouched project reproduces v1.2.9 byte-for-byte. Edited text is confined to the supported text and menu-asset regions. The HUD, cursed-icon, quantity, popup, battle-target, and sound fixes remain in the base release.

## Start with the GUI

Requires **Python 3.10 or newer with Tkinter**. No third-party Python packages are required. Japanese reference text needs a Japanese-capable system font; the GUI prefers a suitable installed font when available. On Windows, install Python with its Tcl/Tk component and Python launcher. On Linux, Tkinter may be a separate distribution package.

1. Extract this entire ZIP into a folder.
2. Start `launch_gui.bat` on Windows, or `sh launch_gui.sh` on Linux/macOS.
3. Choose **Open Project** and open `LadyStalker_v1.2.9_Translation_Project.json`.
4. Choose **Open v1.2.9 ROM** and select your unmodified, headerless v1.2.9 ROM.
5. Edit replacement text. Blank means unchanged. Switching rows, sections, or searches keeps the pending edit in memory.
6. Use **Save Project JSON** to save progress. Reopen that JSON to continue later.
7. Choose **Validate**, then **Build IPS**. Each build also saves a matching `*_project.json` and diagnostic `*_report.json`.
8. Apply the IPS to a fresh copy of **v1.2.9**, then restart the game and test your changed scenes and menus using an in-game save.

The GUI accepts the supplied XLSX workbook too. Edit its yellow replacement/notes columns in a spreadsheet application, save it, then open it in the GUI. GUI saves use JSON; they do not write changes back into the workbook. A report JSON is not an editable project. Builds always start from the exact release ROM, even when resuming a project.

## Included material

- GUI and command-line compiler, with readable Python source.
- JSON project and six-sheet XLSX workbook.
- 1,220 Japanese/current-English dialogue references, 358 lookup strings, and 406 context-specific menu labels.
- TSV reference exports and Japanese text dump.
- Translator guide, technical notes, QA report, and a repeatable compiler verification script.

The current English references include the final battle wording, enemy names, Full Heal, Little Baron 4, and the approved conversational shop text. The full shop greeting and the item confirmation ending in “right?” are retained. Unedited menu artwork is reused exactly, including special spacing. Newly rendered narrow K and Z use the continuous forms from the release.

## What changed in Toolkit 2.1

- Targets the exact v1.2.9 release, including the final HUD repairs and approved shop wording.
- Rebuilds both additional Battle Items artwork copies whenever labels change, including Menu Text-only edits.
- Keeps the native glyphs between name tiles, cache layout, HUD repair code and renderer timing code protected.
- Retains the existing JSON/XLSX editing workflow and validates every generated IPS.

## Command line

Validate:

```text
python ladystalker_translate.py validate My_Project.json Your_v1.2.9_ROM.sfc
```

Build an overlay IPS and optional private test ROM:

```text
python ladystalker_translate.py build My_Project.json Your_v1.2.9_ROM.sfc --output-dir build --name My_Translation --write-rom
```

To build cumulative patches for the original Japanese ROM or ENG v1.0, additionally provide either or both `--japanese-base Original_Japanese_ROM.sfc` and `--eng-v10-base Original_ENG_v1.0.sfc`. Every supplied base is checked, and each IPS is applied internally to verify the result. Share the IPS and project as appropriate; the private test ROM is for local testing.

Run the included compiler checks:

```text
python verify_toolkit.py Your_v1.2.9_ROM.sfc
```

## Supported base hashes

All files are headerless.

| Base | Bytes | SHA-256 |
|---|---:|---|
| English Addendum v1.2.9 | 4,194,304 | `ed72ad227207fb65ad8d3cdd8cfe0a8c21564d7ca147d090670b48d3ae15bfe4` |
| Original Japanese | 2,621,440 | `d0275f6fdc38f26b53b017bdd7fe26e13b9871a93671c76f48800e4f733b2385` |
| ENG v1.0 | 4,194,304 | `3a698798b844e248cd3cf612941d18d1837bc6af1805df18b6eff609bc97e3cf` |

## Scope and limits

The existing fonts support their documented ASCII characters. This tool does not add accented characters, new alphabets, or translate fixed graphical UI labels stored outside the supported tables. Dynamic inserts need in-game checking: a name that fits one window can still make a battle sentence too long.

`<EMPTY>` deliberately empties a string where permitted. In Menu Text, `<FULL>` follows the selected full lookup instead of a fixed abbreviation. Context limits, structural control tags, shared storage capacities, and protected byte boundaries are enforced during compilation.

Older v1.2.8 and v29 projects have different reference text and are rejected. To carry older work forward, transfer only intended replacement/notes cells by stable message ID or lookup/context ID into the new project, then review control tags and validate. Do not replace the new reference columns with old ones. Arbitrary modified ROMs cannot be imported as projects.

See `TRANSLATOR_GUIDE.md`, `TECHNICAL_NOTES.md`, and `QA_REPORT.md` for details.
