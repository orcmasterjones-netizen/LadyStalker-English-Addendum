@echo off
setlocal
cd /d "%~dp0"
py -3 ladystalker_translate.py %*
if errorlevel 1 pause
