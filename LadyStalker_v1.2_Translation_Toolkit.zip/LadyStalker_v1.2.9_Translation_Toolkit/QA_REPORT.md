# Toolkit 2.1 / v1.2.9 verification

Target ROM SHA-256: `ed72ad227207fb65ad8d3cdd8cfe0a8c21564d7ca147d090670b48d3ae15bfe4`.

## Compiler and patch checks

The included `verify_toolkit.py` passed 22 checks against this exact release.

- Both the supplied JSON and XLSX compile to the unchanged v1.2.9 ROM byte for byte. Japanese references are retained.
- Mixed dialogue, item, enemy, phrase, Magic and Status edits compile successfully. Expanded dialogue is repacked inside EB–EC without crossing banks; short edits preserve existing pointers.
- Edited system names and their ASCII copies agree. Unedited aliases, custom spell artwork and repaired narrow K/Z forms survive.
- All 124 Battle item blocks were assigned different test labels. Both packed copies were checked independently against the edited six-tile source blocks: 248 updated copies, correct native gap glyphs, unchanged padding, bank tails and v1.2.9 repair code.
- A Battle Menu Text-only edit updates exactly its two packed copies even when no full lookup changes.
- Invalid control tags, unsupported characters, overlong text, modified references, duplicate rows and storage overflows are rejected.
- IPS application and saved-project rebuilds reproduce the compiled ROM exactly. Build reports are rejected as editable projects.

The command-line build also produced and internally applied three patches for the same mixed-edit ROM: v1.2.9 overlay, original Japanese, and ENG v1.0. All produced the same target bytes with a valid SNES checksum.

## GUI and workbook

Nine GUI workflow checks passed: current workbook/project opening, committing edits across row/section/search changes, saving pending edits, cancelling an unsaved close, building IPS with a resumable project, reopening that project, validation, and rejecting wrong ROMs/reports/older workbooks without replacing the active project.

All six workbook sheets were rendered and inspected. Japanese text is visible in the workbook renders. Formula error scans and exported cached values were checked; blank lookup names now explicitly count as zero across spreadsheet readers. The updated references preserve the full shop greeting and “[item], right?” while including the approved shorter repeated-purchase prompts.

GUI controls were exercised under Linux/Tk 9 on a virtual display. This minimal Tk build did not expose Japanese-capable fonts, so native Japanese GUI rendering was not visually certified here; the underlying reference strings round-tripped unchanged. A normal desktop Python/Tk installation with a Japanese-capable font is required for Japanese display. Windows/macOS launchers were inspected, not run on those operating systems.

## In-game checks

Snes9x checks used newly compiled edited ROMs:

- **124 full-bag rotations:** every distinct edited Battle label appeared in each of the two packed physical slots. Live VRAM matched the intended source block and slot identity; all intervening native glyphs remained correct.
- **14 menu routes / 19,726 frames:** small and full distinct inventories in Items, Gear, Storage, Retrieval and shop Sell; Magic and Stats navigation/reopening with Lady alone, Lady/Cox, Lady/Yosh and all three characters.
- **18 healing routes / 14,747 frames:** edited Medicine in field and battle, small/full inventories and all four party combinations; Cox healing selection in both parties containing Cox. Target names, HP digits/separators, surviving item artwork, cancel/reopen behavior, healing recipient and item consumption were checked. Solo automatic healing also passed.

The menu and healing routes screened every observed frame for all-black flashes and upper-HUD black strips. Representative frames were inspected visually. Battle routes entered an actual battle with the selected party before opening the menus, avoiding stale graphics from an old open-menu save state.

## Scope

These checks validate this toolkit update and representative retranslation paths. They are not a new full-game playthrough, real-console certification, or a guarantee for arbitrary future wording. A blank project preserves the tested release exactly; changed dialogue and labels still need their own in-game checks, especially dynamic name/number inserts. This toolkit does not edit fonts or engine timing code.

No ROM, emulator, save state or test-only renamed project is included in the public toolkit ZIP.
