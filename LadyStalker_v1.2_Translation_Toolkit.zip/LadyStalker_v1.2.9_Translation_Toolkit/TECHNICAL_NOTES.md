# Technical Notes

## Release identity

All compilation starts from the exact 4 MiB v1.2.9 base listed in README. Both supplied project formats must compile to those exact bytes with no replacements. The compiler protects reference/ID fields and rejects missing or duplicate menu rows.

## Supported regions

Addresses are headerless ROM file offsets; endpoints below are inclusive.

| Data | Region | Constraint |
|---|---|---|
| Active dialogue pointers | `0x281000–0x281E4B` | 1,220 active; 15 fallback entries left intact |
| Dialogue | `0x2B0000–0x2CFFFF` | 131,072 bytes; records cannot cross a 64 KiB bank |
| System byte lookups | `0x350000–0x350E43` | 352 records, 3,652 bytes |
| System word lookups | `0x360000–0x361FEF` | Six records |
| ASCII lookup data | `0x2A0004–0x2A0D06` | Shared by 352 names and six phrases |
| ASCII byte pointers | `0x280800–0x280C1F` | 352 entries |
| ASCII word pointers | `0x280C30–0x280C41` | Six entries |
| Status alias resolver/data | `0x352100–0x3523FF` | Existing reserved region only |

The ASCII fallback at `0x2A0000` and old script remnants after the ASCII reservation are preserved. Unedited ASCII aliases are retained even where the release deliberately differs from the system lookup, such as Rock Crush/Rock Crusher.

If a changed dialogue record fits in its old slot, it is replaced in place and padded with END bytes. Otherwise the active dialogue is repacked within EB–EC and its pointers updated. `0x2D0000` begins menu assets and is never treated as script space.

The current system byte table has 20 unused bytes before its boundary. Repacking may reclaim internal padding. The ASCII lookup copy has its own shared capacity; both tables must fit. Shortening another name can fund a longer one.

## Menu assets

The editor resolves full lookup text and context aliases independently. It reuses exact original blocks for unchanged resolved labels and rasterizes changed labels using the release's approved proportional fonts, including repaired K/Z variants.

- Field item map: `0x2822C0`; 124 eight-tile blocks at `0x283000`.
- Storage counts/blocks: `0x2D3000` / `0x2D3200`.
- Shop counts/blocks: `0x2D7000` / `0x2D7200`.
- Battle item counts/blocks: `0x2D0000` / `0x2D0100`; each six-tile block reserves space for quantity after at most five name tiles.
- Packed Battle item copies: `0x2F0000–0x2F7BFF` and `0x2F8000–0x2FFBFF`, 124 fixed 256-byte blocks per copy.
- Magic map/blocks: `0x28B000` / `0x28B200`; block reservation ends before `0x28C000`.
- Status aliases use the existing resolver hook and reserved routine/data region.

The two packed Battle copies are regenerated from the post-edit six-tile blocks at `0x2D0100`. Slot 8 contains tiles 64, 65, 67, 68, 71, 72; slot 9 contains 76, 79, 83, 87, 88, 91. Intervening tiles retain the exact native font glyphs. Only those six name tiles per block are added to the byte allowlist; gap glyphs, FF padding and bank tails stay protected. A no-op build must reproduce all 248 packed blocks exactly. The HUD helpers in C4 and renderer helper at EE:BD00 remain outside the editable regions.

A changed system lookup recomputes item-map source offsets and synchronizes its ASCII copy. Field/Storage/Shop artwork copies and counts remain consistent. An edit to one spell preserves unrelated custom artwork, including Full Heal.

A final byte allowlist rejects changes outside the supported pointer, text, menu-asset, alias, and checksum regions. It does not replace visual QA for new translation lengths or prove every possible future wording safe.

## Patch and project handling

The SNES checksum is updated and verified for changed builds. Every generated IPS is applied internally and must reproduce the compiled target exactly. A no-op build leaves the checksum untouched.

The GUI commits pending edits before row/section/search navigation, save, validation, and build. Closing or replacing a dirty project prompts to save. Each build writes a resumable project JSON separately from its diagnostic report.

The CLI's `--allow-control-changes` bypasses only structural tag comparison. Font, capacity, literal-width, and one-line battle-queue checks still apply. Use it only with a specific reason and scene testing.
