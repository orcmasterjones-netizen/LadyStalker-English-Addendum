#!/usr/bin/env python3
"""Validate and build Lady Stalker v1.2.9 translation projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import ladystalker_core as core
import ladystalker_xlsx as xlsx


def default_stem(project: Path) -> str:
    return project.stem.replace("_Translation_Workspace", "") + "_translation"


def load(project_path: Path, rom_path: Path):
    base = core.checked_release(rom_path)
    project = xlsx.read_project(project_path)
    manifest = core.load_manifest()
    return base, project, manifest


def write_report(path: Path, report: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def checked_optional_base(path: Path, size: int, digest: str, label: str) -> bytes:
    payload = path.read_bytes()
    actual = core.sha256(payload)
    if len(payload) != size or actual != digest:
        raise ValueError(
            f"Unsupported {label}. Expected {size} bytes and SHA-256 {digest}; "
            f"received {len(payload)} bytes and {actual}."
        )
    return payload


def command_validate(args: argparse.Namespace) -> None:
    base, project, manifest = load(args.project, args.rom)
    target, report = core.compile_project(
        base, project, manifest, allow_control_changes=args.allow_control_changes
    )
    report["validation_only"] = True
    if args.report:
        write_report(args.report, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if target == base:
        print("PASS: blank/no-op project reproduces v1.2.9 byte-for-byte.")
    else:
        print("PASS: project compiles safely.")


def command_build(args: argparse.Namespace) -> None:
    base, project, manifest = load(args.project, args.rom)
    target, report = core.compile_project(
        base, project, manifest, allow_control_changes=args.allow_control_changes
    )
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = args.name or default_stem(args.project)
    project_path = output_dir / f"{stem}_project.json"
    xlsx.write_project(project_path, project)
    ips_path = output_dir / f"{stem}_for_v1.2.9.ips"
    ips_report = core.write_ips(base, target, ips_path)
    rebuilt = core.apply_ips(base, ips_path.read_bytes())
    if rebuilt != target:
        raise ValueError("Internal IPS round-trip verification failed")
    report["overlay_patch"] = {"path": str(ips_path), **ips_report}
    report["saved_project"] = str(project_path)
    direct_patches: dict[str, object] = {}
    for label, path, size, digest, suffix in (
        ("Japanese ROM", args.japanese_base, 0x280000, core.JP_SHA256, "for_Japanese_ROM"),
        ("ENG v1.0 ROM", args.eng_v10_base, 0x400000, core.ENG_V10_SHA256, "for_ENGv10_ROM"),
    ):
        if path is None:
            continue
        direct_base = checked_optional_base(path, size, digest, label)
        direct_path = output_dir / f"{stem}_{suffix}.ips"
        direct_report = core.write_ips(direct_base, target, direct_path)
        if core.apply_ips(direct_base, direct_path.read_bytes()) != target:
            raise ValueError(f"Internal {label} IPS round-trip verification failed")
        direct_patches[label] = {"path": str(direct_path), **direct_report}
    if direct_patches:
        report["direct_base_patches"] = direct_patches
    if args.write_rom:
        rom_path = output_dir / f"{stem}.sfc"
        rom_path.write_bytes(target)
        report["private_test_rom"] = str(rom_path)
    report_path = output_dir / f"{stem}_build_report.json"
    write_report(report_path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"Built: {ips_path}")
    print(f"Project: {project_path}")
    print(f"Report: {report_path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    def common(subparser: argparse.ArgumentParser) -> None:
        subparser.add_argument("project", type=Path, help="translation workbook (.xlsx) or project (.json)")
        subparser.add_argument("rom", type=Path, help="exact headerless v1.2.9 .sfc ROM")
        subparser.add_argument(
            "--allow-control-changes",
            action="store_true",
            help="allow structural dialogue control tags to change (advanced and risky)",
        )

    validate = subparsers.add_parser("validate", help="validate without writing a patch")
    common(validate)
    validate.add_argument("--report", type=Path)
    validate.set_defaults(func=command_validate)

    build = subparsers.add_parser("build", help="build a v1.2.9 overlay IPS patch")
    common(build)
    build.add_argument("--output-dir", type=Path, default=Path("build"))
    build.add_argument("--name", help="output filename stem")
    build.add_argument("--write-rom", action="store_true", help="also write a private test ROM")
    build.add_argument("--japanese-base", type=Path, help="also build a patch for the exact original Japanese ROM")
    build.add_argument("--eng-v10-base", type=Path, help="also build a patch for the exact Lady Stalker ENG v1.0 ROM")
    build.set_defaults(func=command_build)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
