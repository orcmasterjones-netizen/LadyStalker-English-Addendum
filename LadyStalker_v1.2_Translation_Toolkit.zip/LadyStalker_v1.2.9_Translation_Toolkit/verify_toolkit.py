#!/usr/bin/env python3
"""Reproducible compiler checks. Usage: python verify_toolkit.py Your_v1.2.9.sfc"""
import argparse, copy, json, tempfile
from pathlib import Path
import ladystalker_core as c
import ladystalker_xlsx as x

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom',type=Path)
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    base=c.checked_release(args.rom);manifest=c.load_manifest()
    project=x.read_project(root/'LadyStalker_v1.2.9_Translation_Project.json')
    checks=[]
    def record(name):
        checks.append(name);print('PASS:',name,flush=True)
    for suffix in ('Project.json','Workspace.xlsx'):
        data=x.read_project(root/f'LadyStalker_v1.2.9_Translation_{suffix}')
        target,report=c.compile_project(base,data,manifest)
        assert target==base
        for key in ('dialogue','lookups','menu_text'):
            assert [r['japanese_reference'] for r in data[key]]==[r['japanese_reference'] for r in project[key]]
        record('Exact no-op and Japanese references: '+suffix)
    changed=copy.deepcopy(project)
    changed['dialogue'][0]['replacement_text']='Nothing here.<WAIT_INPUT>'
    changed['dialogue'][1]['replacement_text']='Lady opened the chest\nand looked inside.'
    for i,new in [(226,'Spade'),(127,'Gustaf'),(352,'Ms.')]:
        changed['lookups'][i]['replacement_text']=new
    for row in changed['lookups']:
        if row['english_reference']=='Medicine':row['replacement_text']='Med Kit'
        if row['english_reference']=='Zuga':row['replacement_text']='Zika'
    menu=c.menu_rows_by_key(changed)
    menu[('field_item',226)]['replacement_menu_text']='Zinc Key'
    menu[('battle_item',226)]['replacement_menu_text']='ZincKey'
    menu[('status',181)]['replacement_menu_text']='HealAll'
    target,report=c.compile_project(base,changed,manifest)
    assert report['changed_messages']==2 and report['snes_checksum_valid']
    assert target[0x2a0d07:0x2b0000]==base[0x2a0d07:0x2b0000]
    assert target[0x2a0000:0x2a0004]==base[0x2a0000:0x2a0004]
    record('Mixed dialogue, item, enemy, phrase, Magic and Status edits')
    assert c.extract_messages(target)[1].text==changed['dialogue'][1]['replacement_text']
    assert all((m.offset>>16)==((m.offset+len(m.raw)-1)>>16) for m in c.extract_messages(target))
    record('Expanded dialogue repacks within EB-EC without crossing banks')
    old_ascii=c.parse_ascii_lookups(base);new_ascii=c.parse_ascii_lookups(target)
    for i,(old,row) in enumerate(zip(old_ascii,changed['lookups'],strict=True)):
        edit=row['replacement_text']
        expected=edit.encode('ascii').replace(b' ',b'\x01') if edit else old
        assert new_ascii[i]==expected,(i,new_ascii[i],expected)
    record('Edited ASCII copies synchronized; intentional unedited aliases retained')
    # Unchanged custom Full Heal artwork must survive another spell's edit.
    for index in (181,169):
        a=base[c.SPELL_MAP_OFFSET+(index-147)*2]
        b=target[c.SPELL_MAP_OFFSET+(index-147)*2]
        if a!=255:
            assert target[c.SPELL_TILE_DATA_OFFSET+b*64:c.SPELL_TILE_DATA_OFFSET+(b+1)*64]==base[c.SPELL_TILE_DATA_OFFSET+a*64:c.SPELL_TILE_DATA_OFFSET+(a+1)*64]
    glyphs=c.build_field_glyph_sets(base)
    assert glyphs[3]['K'][0]==[5,5,6,6,6,5,5,0]
    assert glyphs[3]['Z'][0]==[7,1,1,2,4,4,7,0]
    assert glyphs[4]['K'][0]==[9,10,12,12,12,10,9,0]
    assert glyphs[4]['Z'][0]==[15,1,2,2,4,8,15,0]
    record('Original special artwork and corrected narrow K/Z preserved')
    # Exercise every compact block with a different edited label. Validate
    # the uploaded spans independently of the production packing helper.
    stress=copy.deepcopy(project)
    for i,row in enumerate(r for r in stress['menu_text'] if r['context']=='battle_item'):
        row['replacement_menu_text']=f'ZK{i:03d}'
    stress_target,stress_report=c.compile_project(base,stress,manifest)
    assert stress_report['battle_item_labels_rebuilt']==124
    assert stress_report['packed_battle_blocks_changed']==248
    for source in (base,target,stress_target):
        for slot,destination,codes in c.BATTLE_PACKED_SLOTS:
            first,last=min(codes),max(codes)
            for block in range(124):
                packed=destination+block*256
                for code in range(first,last+1):
                    offset=(0x2d0100+block*96+codes.index(code)*16
                            if code in codes else 0x45576+code*16)
                    actual=packed+(code-first)*16
                    assert source[actual:actual+16]==source[offset:offset+16],(slot,block,code)
                assert source[packed+(last-first+1)*16:packed+256]==b'\xff'*(256-(last-first+1)*16)
        for a,b in ((0x04de9f,0x04e000),(0x042f2d,0x042f30),(0x043b40,0x043b43),
                    (0x28d597,0x28d59b),(0x2ebd00,0x2ebd9f),(0x28da00,0x28da90),
                    (0x352480,0x352510),(0x2f7c00,0x2f8000),(0x2ffc00,0x300000)):
            assert source[a:b]==base[a:b],(a,b)
    record('All 124 distinct edited Battle names rebuild both packed copies; native gaps, padding and v1.2.9 hooks preserved')
    # A menu-only edit must refresh the copies even without a lookup edit.
    only=copy.deepcopy(project)
    c.menu_rows_by_key(only)[('battle_item',226)]['replacement_menu_text']='ZincKey'
    _,single_report=c.compile_project(base,only,manifest)
    assert single_report['changed_byte_lookups']==0 and single_report['packed_battle_blocks_changed']==2
    record('Battle menu-only edit refreshes exactly two packed blocks')
    short=copy.deepcopy(project);short['dialogue'][0]['replacement_text']='Nothing.<WAIT_INPUT>'
    out,_=c.compile_project(base,short,manifest)
    assert out[c.POINTER_TABLE:c.POINTER_TABLE+1235*3]==base[c.POINTER_TABLE:c.POINTER_TABLE+1235*3]
    record('Shorter dialogue edits preserve existing pointers')
    failures=[
        ('Missing control',lambda p:p['dialogue'][0].update(replacement_text='Nothing.')),
        ('Unsupported character',lambda p:p['dialogue'][1].update(replacement_text='Caf\u00e9')),
        ('Wide dialogue',lambda p:p['dialogue'][1].update(replacement_text='W'*90)),
        ('Battle line break',lambda p:p['dialogue'][0x43].update(replacement_text=p['dialogue'][0x43]['english_reference']+'\n')),
        ('Battle literal overflow',lambda p:p['dialogue'][0x43].update(replacement_text=p['dialogue'][0x43]['english_reference']+'W'*32)),
        ('Reference edit',lambda p:p['lookups'][0].update(english_reference='Other')),
        ('Duplicate menu row',lambda p:p['menu_text'].__setitem__(1,copy.deepcopy(p['menu_text'][0]))),
        ('Battle name overflow',lambda p:c.menu_rows_by_key(p)[('battle_item',226)].update(replacement_menu_text='ABCDEFGHI')),
        ('Status overflow',lambda p:c.menu_rows_by_key(p)[('status',181)].update(replacement_menu_text='ABCDEFGHI')),
        ('System lookup overflow',lambda p:p['lookups'][0].update(replacement_text='A'*253)),
        ('ASCII shared table overflow',lambda p:p['lookups'][352].update(replacement_text='A'*126)),
        ('Dialogue bank overflow',lambda p:p['dialogue'][1].update(replacement_text=('word\n'*14000))),
    ]
    for name,mutate in failures:
        p=copy.deepcopy(project);mutate(p)
        try:c.compile_project(base,p,manifest)
        except ValueError:record('Rejected: '+name)
        else:raise AssertionError(name+' was accepted')
    with tempfile.TemporaryDirectory() as temporary:
        d=Path(temporary);c.write_ips(base,target,d/'edit.ips')
        assert c.apply_ips(base,(d/'edit.ips').read_bytes())==target
        x.write_project(d/'edit_project.json',changed)
        assert c.compile_project(base,x.read_project(d/'edit_project.json'),manifest)[0]==target
        (d/'edit_report.json').write_text(json.dumps(report))
        try:x.read_project(d/'edit_report.json')
        except ValueError as e:assert 'build report' in str(e)
        else:raise AssertionError('Report accepted as project')
    record('IPS round-trip, project save/resume, and report rejection')
    if args.output_dir:
        args.output_dir.mkdir(parents=True,exist_ok=True)
        (args.output_dir/'edited_test.sfc').write_bytes(target)
        (args.output_dir/'all_battle_names_test.sfc').write_bytes(stress_target)
        x.write_project(args.output_dir/'all_battle_names_project.json',stress)
        x.write_project(args.output_dir/'edited_test_project.json',changed)
        (args.output_dir/'compiler_report.json').write_text(json.dumps({'checks':checks,'build':report},indent=2)+'\n')
    print(f'{len(checks)} checks passed.')

if __name__=='__main__':main()
