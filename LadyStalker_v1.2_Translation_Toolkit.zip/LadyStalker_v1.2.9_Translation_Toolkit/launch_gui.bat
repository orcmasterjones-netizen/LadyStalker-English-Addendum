@echo off
setlocal
cd /d "%~dp0"
start "Lady Stalker v1.2.9 Translation Toolkit" pyw -3 ladystalker_translation_gui.py
