#!/usr/bin/env python3
"""Tkinter editor and safe patch builder for Lady Stalker v1.2.9 translations."""

from __future__ import annotations

import copy
import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk, font as tkfont

import ladystalker_core as core
import ladystalker_xlsx as xlsx


KINDS = ("Dialogue", "Lookups", "Menu Text")
PROJECT_KEYS = {"Dialogue": "dialogue", "Lookups": "lookups", "Menu Text": "menu_text"}


class TranslationGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Lady Stalker v1.2.9 Translation Toolkit")
        self.geometry("1180x760")
        self.minsize(920, 620)
        self.project: dict[str, list[dict[str, str]]] | None = None
        self.project_path: Path | None = None
        self.rom_path: Path | None = None
        self.rom: bytes | None = None
        self.visible_rows: list[int] = []
        self.current_source_index: int | None = None
        self.current_row: dict[str, str] | None = None
        self.current_kind: str | None = None
        self.dirty = False
        self.kind = tk.StringVar(value="Dialogue")
        self.search = tk.StringVar()
        self.status = tk.StringVar(value="Open the supplied workbook or JSON project to begin.")
        self.metric = tk.StringVar(value="")
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self.close_project)
        self.bind("<Control-s>", lambda _event: self.save_project())

    def _build_ui(self) -> None:
        toolbar = ttk.Frame(self, padding=8)
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="Open Project", command=self.open_project).pack(side="left")
        ttk.Button(toolbar, text="Open v1.2.9 ROM", command=self.open_rom).pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="Save Project JSON", command=self.save_project).pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="Validate", command=self.validate).pack(side="left", padx=(18, 0))
        ttk.Button(toolbar, text="Build IPS", command=self.build_patch).pack(side="left", padx=(6, 0))
        ttk.Label(toolbar, textvariable=self.status).pack(side="left", padx=16, fill="x", expand=True)

        filters = ttk.Frame(self, padding=(8, 0, 8, 8))
        filters.pack(fill="x")
        ttk.Label(filters, text="Section:").pack(side="left")
        section = ttk.Combobox(filters, textvariable=self.kind, values=KINDS, state="readonly", width=14)
        section.pack(side="left", padx=(6, 18))
        section.bind("<<ComboboxSelected>>", lambda _event: self.refresh_rows())
        ttk.Label(filters, text="Search:").pack(side="left")
        entry = ttk.Entry(filters, textvariable=self.search)
        entry.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.search.trace_add("write", lambda *_args: self.refresh_rows())

        paned = ttk.Panedwindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        left = ttk.Frame(paned)
        right = ttk.Frame(paned, padding=(10, 0, 0, 0))
        paned.add(left, weight=3)
        paned.add(right, weight=4)

        self.tree = ttk.Treeview(left, columns=("id", "category", "current", "edit"), show="headings", selectmode="browse")
        for column, label, width in (
            ("id", "ID", 90), ("category", "Context", 110),
            ("current", "Current v1.2.9", 230), ("edit", "Replacement", 230),
        ):
            self.tree.heading(column, text=label)
            self.tree.column(column, width=width, stretch=column in ("current", "edit"))
        scroll = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.select_row)

        ttk.Label(right, text="Japanese reference").pack(anchor="w")
        self.japanese = tk.Text(right, height=8, wrap="word", state="disabled")
        available_fonts = set(tkfont.families(self))
        for family in ("Yu Gothic", "Meiryo", "Noto Sans CJK JP", "Hiragino Sans", "MS Gothic"):
            if family in available_fonts:
                self.japanese.configure(font=(family, 11))
                break
        self.japanese.pack(fill="both", expand=True, pady=(3, 8))
        ttk.Label(right, text="Current v1.2.9 text").pack(anchor="w")
        self.current = tk.Text(right, height=6, wrap="word", state="disabled")
        self.current.pack(fill="both", expand=True, pady=(3, 8))
        ttk.Label(right, text="Replacement (blank = unchanged; <EMPTY> = intentionally empty)").pack(anchor="w")
        self.replacement = tk.Text(right, height=7, wrap="word", undo=True)
        self.replacement.pack(fill="both", expand=True, pady=(3, 5))
        self.replacement.bind("<KeyRelease>", lambda _event: self.update_metric())
        ttk.Label(right, textvariable=self.metric, foreground="#0B4F6C").pack(anchor="w", pady=(0, 6))
        buttons = ttk.Frame(right)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Apply Edit", command=self.apply_edit).pack(side="left")
        ttk.Button(buttons, text="Clear / Use v1.2.9", command=self.clear_edit).pack(side="left", padx=(6, 0))

    def set_text(self, widget: tk.Text, value: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        widget.configure(state="disabled")

    def open_project(self) -> None:
        filename = filedialog.askopenfilename(filetypes=[("Translation project", "*.xlsx *.json"), ("All files", "*.*")])
        if not filename:
            return
        try:
            path = Path(filename)
            project = xlsx.read_project(path)
            if self.rom is not None:
                core.validate_project(project, core.load_manifest(), self.rom)
        except Exception as error:
            messagebox.showerror("Cannot open project", str(error))
            return
        if not self.confirm_unsaved():
            return
        self.current_row = None
        self.current_kind = None
        self.project = copy.deepcopy(project)
        self.project_path = Path(filename)
        self.dirty = False
        self.status.set(f"Project: {self.project_path.name}")
        self.refresh_rows()

    def open_rom(self) -> None:
        filename = filedialog.askopenfilename(filetypes=[("SNES ROM", "*.sfc *.smc"), ("All files", "*.*")])
        if not filename:
            return
        try:
            rom = core.checked_release(Path(filename))
            if self.project is not None:
                core.validate_project(self.project, core.load_manifest(), rom)
        except Exception as error:
            messagebox.showerror("Unsupported ROM", str(error))
            return
        self.rom_path = Path(filename)
        self.rom = rom
        self.status.set(f"v1.2.9 verified: {self.rom_path.name}")
        self.update_metric()

    def rows(self) -> list[dict[str, str]]:
        if self.project is None:
            return []
        return self.project[PROJECT_KEYS[self.kind.get()]]

    def row_summary(self, row: dict[str, str]) -> tuple[str, str, str, str]:
        kind = self.kind.get()
        if kind == "Dialogue":
            return row["message_id"], row.get("category", ""), row["english_reference"].replace("\n", " ↵ "), row.get("replacement_text", "").replace("\n", " ↵ ")
        if kind == "Lookups":
            return f"{row['table']}:{row['index']}", row.get("category", ""), row["english_reference"], row.get("replacement_text", "")
        return str(row['lookup_index']), row["context"], row["current_menu_text"], row.get("replacement_menu_text", "")

    def refresh_rows(self) -> None:
        self.commit_edit()
        self.current_source_index = None
        self.current_row = None
        self.current_kind = None
        self.tree.delete(*self.tree.get_children())
        self.visible_rows = []
        needle = self.search.get().casefold().strip()
        for index, row in enumerate(self.rows()):
            summary = self.row_summary(row)
            if needle and needle not in " ".join(summary).casefold() and needle not in row.get("japanese_reference", "").casefold():
                continue
            self.visible_rows.append(index)
            self.tree.insert("", "end", iid=str(index), values=summary)
        self.metric.set(f"{len(self.visible_rows)} rows shown")
        self.set_text(self.japanese, "")
        self.set_text(self.current, "")
        self.replacement.delete("1.0", "end")
        self.replacement.edit_reset()

    def select_row(self, _event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        self.commit_edit()
        index = int(selection[0])
        self.current_source_index = index
        row = self.rows()[index]
        kind = self.kind.get()
        self.current_row = row
        self.current_kind = kind
        current_key = "current_menu_text" if kind == "Menu Text" else "english_reference"
        replacement_key = "replacement_menu_text" if kind == "Menu Text" else "replacement_text"
        self.set_text(self.japanese, row.get("japanese_reference", ""))
        self.set_text(self.current, row.get(current_key, ""))
        self.replacement.delete("1.0", "end")
        self.replacement.insert("1.0", row.get(replacement_key, ""))
        self.replacement.edit_reset()
        self.update_metric()

    def replacement_value(self) -> str:
        return self.replacement.get("1.0", "end-1c")

    def commit_edit(self) -> None:
        # The section may already have changed; write to the actual previous row.
        if self.current_row is None:
            return
        key = "replacement_menu_text" if self.current_kind == "Menu Text" else "replacement_text"
        value = self.replacement_value()
        if value != self.current_row.get(key, ""):
            self.current_row[key] = value
            self.dirty = True
            if self.current_kind == self.kind.get() and self.tree.exists(str(self.current_source_index)):
                self.tree.item(str(self.current_source_index), values=self.row_summary(self.current_row))

    def confirm_unsaved(self) -> bool:
        self.commit_edit()
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("Unsaved project", "Save your translation edits before continuing?")
        if answer is None:
            return False
        return self.save_project() if answer else True

    def close_project(self) -> None:
        if self.confirm_unsaved():
            self.destroy()

    def apply_edit(self) -> None:
        if self.current_source_index is None:
            return
        index = self.current_source_index
        self.commit_edit()
        self.refresh_rows()
        if self.tree.exists(str(index)):
            self.tree.selection_set(str(index))
            self.tree.see(str(index))
        self.status.set("Edit applied in memory; save JSON or build when ready.")

    def clear_edit(self) -> None:
        self.replacement.delete("1.0", "end")
        self.apply_edit()

    def selected_full_text(self, lookup_index: int) -> str:
        assert self.project is not None
        row = self.project["lookups"][lookup_index]
        replacement = row.get("replacement_text", "")
        selected = replacement if replacement != "" else row["english_reference"]
        return "" if selected == "<EMPTY>" else selected

    def update_metric(self) -> None:
        if self.current_source_index is None or self.project is None:
            return
        row = self.rows()[self.current_source_index]
        edit = self.replacement_value()
        selected = edit if edit != "" else (
            row["current_menu_text"] if self.kind.get() == "Menu Text" else row["english_reference"]
        )
        try:
            if self.kind.get() == "Dialogue":
                raw = core.compile_main(selected)
                if self.rom is None:
                    self.metric.set(f"Encoded bytes: {len(raw)}. Open v1.2.9 ROM for live pixel width.")
                else:
                    metrics = core.dialogue_metrics(raw, core.dialogue_advances(self.rom))
                    self.metric.set(f"Encoded bytes: {len(raw)} | widest literal line: {metrics['max_literal_line_width']}/{core.DIALOGUE_LINE_BUDGET} units")
            elif self.kind.get() == "Lookups":
                raw = core.compile_system(selected)
                limit = 253 if row["table"] == "byte" else 126
                self.metric.set(f"Encoded characters: {len(raw)}/{limit}; Validate checks the shared table capacity.")
            elif self.rom is None:
                self.metric.set(f"Configured limit: {row['width_limit']}. Open v1.2.9 ROM for exact proportional measurement.")
            else:
                index = core.parse_index(row["lookup_index"])
                full = self.selected_full_text(index)
                probe = dict(row)
                probe["replacement_menu_text"] = edit
                label = core.resolve_menu_text(probe, full)
                context = row["context"]
                if label == row["current_menu_text"] and context != "status":
                    self.metric.set(f"Original v1.2.9 artwork preserved | limit: {row['width_limit']} pixels")
                    return
                if context == "field_item":
                    _chunks, pixels, width, _trim = core.render_field_label(label, core.build_field_glyph_sets(self.rom))
                    self.metric.set(f"{pixels}/64 pixels using {width}-column glyphs")
                elif context == "battle_item":
                    _chunks, pixels, _trim = core.render_battle_label(label, core.build_battle_glyphs(self.rom))
                    self.metric.set(f"{len(label)}/8 characters | {pixels}/40 pixels")
                elif context == "magic":
                    _chunks, pixels, width, _trim = core.render_spell_label(label, core.build_field_glyph_sets(self.rom), index == core.SPELL_FINAL_ROW_INDEX)
                    self.metric.set(f"{pixels}/{row['width_limit']} pixels using {width}-column glyphs")
                else:
                    cells = len(core.compile_system(label))
                    self.metric.set(f"{cells}/{row['width_limit']} status cells")
        except Exception as error:
            self.metric.set(f"DOES NOT FIT: {error}")

    def save_project(self) -> bool:
        if self.project is None:
            messagebox.showinfo("No project", "Open a workbook or project first.")
            return False
        self.commit_edit()
        filename = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("Translation project", "*.json")], initialfile=self.project_path.with_suffix('.json').name if self.project_path else 'My_Translation_project.json')
        if not filename:
            return False
        try:
            xlsx.write_project(Path(filename), self.project)
            self.project_path = Path(filename)
            self.dirty = False
            self.status.set(f"Saved: {Path(filename).name}")
            return True
        except Exception as error:
            messagebox.showerror("Save failed", str(error))
            return False

    def compile(self):
        if self.project is None or self.rom is None:
            raise ValueError("Open both a translation project and the exact v1.2.9 ROM first.")
        self.commit_edit()
        return core.compile_project(self.rom, self.project, core.load_manifest())

    def validate(self) -> None:
        try:
            _target, report = self.compile()
        except Exception as error:
            messagebox.showerror("Validation failed", str(error))
            return
        messagebox.showinfo("Validation passed", f"Changed bytes: {report['changed_bytes']:,}\nMessages: {report['changed_messages']}\nLookups: {report['changed_byte_lookups'] + report['changed_word_lookups']}\nMenu overrides: {report['changed_menu_overrides']}")

    def build_patch(self) -> None:
        try:
            target, report = self.compile()
        except Exception as error:
            messagebox.showerror("Build blocked", str(error))
            return
        filename = filedialog.asksaveasfilename(defaultextension=".ips", filetypes=[("IPS patch", "*.ips")], initialfile="LadyStalker_v1.2.9_Custom_Translation.ips")
        if not filename:
            return
        try:
            path = Path(filename)
            project_path = path.with_name(path.stem + "_project.json")
            xlsx.write_project(project_path, self.project)
            core.write_ips(self.rom, target, path)
            if core.apply_ips(self.rom, path.read_bytes()) != target:
                raise ValueError("IPS verification failed")
            report_path = path.with_name(path.stem + "_report.json")
            report["saved_project"] = str(project_path)
            report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            self.project_path = project_path
            self.dirty = False
            messagebox.showinfo(
                "Build complete",
                f"Verified patch:\n{path}\n\nSaved project:\n{project_path}\n\nReport:\n{report_path}",
            )
        except Exception as error:
            messagebox.showerror("Build failed", str(error))


if __name__ == "__main__":
    TranslationGUI().mainloop()
