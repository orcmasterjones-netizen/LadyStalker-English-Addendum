#!/usr/bin/env python3
"""Validation and reinsertion engine for the frozen Lady Stalker English v1.2.9 ROM."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ROM_SIZE = 0x400000
RELEASE_SHA256 = "ed72ad227207fb65ad8d3cdd8cfe0a8c21564d7ca147d090670b48d3ae15bfe4"
JP_SHA256 = "d0275f6fdc38f26b53b017bdd7fe26e13b9871a93671c76f48800e4f733b2385"
ENG_V10_SHA256 = "3a698798b844e248cd3cf612941d18d1837bc6af1805df18b6eff609bc97e3cf"

MESSAGE_COUNT = 1220
POINTER_ENTRY_COUNT = 1235
POINTER_TABLE = 0x281000
SCRIPT_START = 0x2B0000
SCRIPT_END = 0x2D0000  # ED:0000 begins v1.2.9's compact item cache assets.

BYTE_LOOKUP_BASE = 0x350000
BYTE_LOOKUP_COUNT = 352
BYTE_LOOKUP_LIMIT = 0x350E44  # v1.2.9 field-pattern data begins immediately here.
WORD_LOOKUP_BASE = 0x360000
WORD_LOOKUP_COUNT = 6
WORD_LOOKUP_LIMIT = 0x361FF0
ASCII_BYTE_POINTERS = 0x280800
ASCII_WORD_POINTERS = 0x280C30
# Keep EA:0000's fallback text and the older script remnant after EA:0D06.
ASCII_START = 0x2A0004
ASCII_LIMIT = 0x2A0D07

CHECKSUM_OFFSET = 0x00FFDC
SYSTEM_FONT_OFFSET = 0x045576
SYSTEM_FONT_BYTES_PER_GLYPH = 16
DIALOGUE_FONT_BASE = 0x290000
DIALOGUE_FONT_BYTES_PER_GLYPH = 30
SPACE_ADVANCE_IMMEDIATE_OFFSET = 0x0502B1
DIALOGUE_LINE_BUDGET = 240
BATTLE_QUEUE_SINGLE_LINE_IDS = frozenset(range(0x0043, 0x006E))

MENU_ALIAS_MAP_OFFSET = 0x2822C0
MENU_ALIAS_MAP_LIMIT = 0x283000
PROPORTIONAL_TILE_DATA_OFFSET = 0x283000
PROPORTIONAL_TILES_PER_SLOT = 8
PROPORTIONAL_TILE_BLOCK_BYTES = 0x80
STORAGE_COUNT_TABLE_OFFSET = 0x2D3000
STORAGE_TILE_DATA_OFFSET = 0x2D3200
SHOP_COUNT_TABLE_OFFSET = 0x2D7000
SHOP_TILE_DATA_OFFSET = 0x2D7200

BATTLE_COUNT_TABLE_OFFSET = 0x2D0000
BATTLE_TILE_DATA_OFFSET = 0x2D0100
BATTLE_TILES_PER_BLOCK = 6
BATTLE_NAME_TILE_LIMIT = 5
BATTLE_BLOCK_COUNT = 124
BATTLE_SLOT_TABLE_OFFSET = 0x28DA00
BATTLE_PACKED_PITCH = 256
# Runtime slot layouts are fixed by v1.2.9's timing-preserving renderer.
BATTLE_PACKED_SLOTS = (
    (8, 0x2F0000, (64, 65, 67, 68, 71, 72)),
    (9, 0x2F8000, (76, 79, 83, 87, 88, 91)),
)

SPELL_LOOKUP_FIRST = 147
SPELL_LOOKUP_LAST = 225
SPELL_MAP_OFFSET = 0x28B000
SPELL_TILE_DATA_OFFSET = 0x28B200
SPELL_TILE_DATA_LIMIT = 0x28C000
SPELL_TILES_PER_BLOCK = 4
SPELL_TILE_BLOCK_BYTES = 0x40
SPELL_FINAL_ROW_INDEX = 172

STATUS_ROUTINE_OFFSET = 0x352100
STATUS_ALIAS_DATA_OFFSET = 0x352200
STATUS_RESERVED_END = 0x352400
STATUS_LOOKUP_HOOK_OFFSET = 0x0414B7
STATUS_LOOKUP_CALL = bytes.fromhex("22 00 21 F5")

TAG_TO_CODE = {
    "<NOP>": 0xC1,
    "<NUMBER>": 0xC2,
    "<LINE>": 0xC3,
    "<INSERT_A>": 0xC4,
    "<WAIT>": 0xC5,
    "<PAUSE_60_A>": 0xC6,
    "<PAUSE_30_A>": 0xC7,
    "<WAIT_INPUT>": 0xC9,
    "<INSERT_B>": 0xCA,
    "<PAUSE_60>": 0xCB,
    "<SPEAKER>": 0xCC,
    "<PAUSE_30>": 0xCD,
    "<INSERT_C>": 0xCE,
    "<INSERT_D>": 0xCF,
    "<CLEAR>": 0xD0,
    "<INSERT_BUFFER>": 0xD1,
}
CODE_TO_TAG = {value: key for key, value in TAG_TO_CODE.items()}
STRUCTURAL_CONTROLS = set(range(0xC1, 0xD2)) - {0xC3, 0xC8}
LINE_BOUNDARY_CONTROLS = {0xC3, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCB, 0xCD, 0xD0}
DYNAMIC_INSERT_CONTROLS = {0xC2, 0xC4, 0xCA, 0xCC, 0xCE, 0xCF, 0xD1}


def build_system_charset() -> tuple[dict[int, str], dict[str, int]]:
    table: dict[int, str] = {0x01: " ", 0x0C: "L", 0x0D: "S", 0x0E: "P", 0x0F: "Y"}
    for code, character in enumerate("0123456789", 0x02):
        table[code] = character
    for code, character in enumerate("!\"#$%&'()*+,-./", 0x10):
        table[code] = character
    for code, character in enumerate(":;<=>?@", 0x1F):
        table[code] = character
    capital_codes = [
        *range(0x26, 0x31), 0x0C, *range(0x31, 0x34), 0x0E,
        *range(0x34, 0x36), 0x0D, *range(0x36, 0x3B), 0x0F, 0x3B,
    ]
    for code, character in zip(capital_codes, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", strict=True):
        table[code] = character
    for code, character in enumerate("[\\]^_`", 0x3C):
        table[code] = character
    for code, character in enumerate("abcdefghijklmnopqrstuvwxyz", 0x42):
        table[code] = character
    for code, character in enumerate("{|}~", 0x5C):
        table[code] = character
    return table, {character: code for code, character in table.items()}


SYSTEM_CHARSET, SYSTEM_REVERSE = build_system_charset()


@dataclass(frozen=True)
class Message:
    ordinal: int
    pointer: int
    offset: int
    raw: bytes
    text: str


@dataclass(frozen=True)
class ItemMapEntry:
    lookup_index: int
    block: int
    count: int
    position: int


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def checked_release(path: Path) -> bytes:
    payload = path.read_bytes()
    if len(payload) != ROM_SIZE or sha256(payload) != RELEASE_SHA256:
        raise ValueError(
            "Unsupported base ROM. The translation overlay requires the exact frozen v1.2.9 "
            f"release ({ROM_SIZE} bytes, SHA-256 {RELEASE_SHA256})."
        )
    return payload


def cpu_to_file(pointer: int) -> int:
    return ((pointer >> 16) & 0x3F) * 0x10000 + (pointer & 0xFFFF)


def file_to_cpu(offset: int) -> int:
    return ((0xC0 + offset // 0x10000) << 16) | (offset & 0xFFFF)


def render_main(raw: bytes) -> str:
    pieces: list[str] = []
    for code in raw:
        if code == 0xC0:
            break
        if code == 0x01:
            pieces.append(" ")
        elif code == 0xC8:
            pieces.append("\n")
        elif code in CODE_TO_TAG:
            pieces.append(CODE_TO_TAG[code])
        elif 0x20 <= code <= 0x7E:
            pieces.append(chr(code))
        else:
            pieces.append(f"<GLYPH_{code:02X}>")
    return "".join(pieces)


def compile_main(text: str) -> bytes:
    if text == "<EMPTY>":
        return b"\xC0"
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    output = bytearray()
    index = 0
    while index < len(text):
        character = text[index]
        if character == "\n":
            output.append(0xC8)
            index += 1
            continue
        if character == "<":
            close = text.find(">", index + 1)
            if close >= 0:
                token = text[index : close + 1]
                if token in TAG_TO_CODE:
                    output.append(TAG_TO_CODE[token])
                    index = close + 1
                    continue
                if token.startswith(("<CTRL_", "<GLYPH_")):
                    raise ValueError(f"Unsupported raw dialogue token {token}")
        if character == " ":
            output.append(0x01)
        elif 0x21 <= ord(character) <= 0x7E:
            output.append(ord(character))
        else:
            raise ValueError(f"Dialogue character {character!r} is not supported by v1.2.9")
        index += 1
    output.append(0xC0)
    return bytes(output)


def compile_system(text: str) -> bytes:
    if text == "<EMPTY>":
        return b""
    output = bytearray()
    for character in text:
        try:
            output.append(SYSTEM_REVERSE[character])
        except KeyError as error:
            raise ValueError(f"System-font character {character!r} is not supported by v1.2.9") from error
    return bytes(output)


def decode_system(raw: bytes) -> str:
    try:
        return "".join(SYSTEM_CHARSET[code] for code in raw)
    except KeyError as error:
        raise ValueError(f"Unsupported system-font code 0x{error.args[0]:02X}") from error


def extract_messages(rom: bytes) -> list[Message]:
    messages: list[Message] = []
    for ordinal in range(POINTER_ENTRY_COUNT):
        entry = POINTER_TABLE + ordinal * 3
        pointer = int.from_bytes(rom[entry : entry + 2], "little") | rom[entry + 2] << 16
        if ordinal >= MESSAGE_COUNT:
            if pointer != 0xFFFFFF:
                raise ValueError(f"Fallback pointer {ordinal} is not FF:FFFF")
            continue
        if pointer == 0xFFFFFF:
            raise ValueError(f"Message {ordinal:04X} has no direct pointer")
        offset = cpu_to_file(pointer)
        end = rom.find(b"\xC0", offset, min(len(rom), (offset & ~0xFFFF) + 0x10000))
        if end < 0:
            raise ValueError(f"Message {ordinal:04X} has no END byte")
        raw = rom[offset : end + 1]
        messages.append(Message(ordinal, pointer, offset, raw, render_main(raw)))
    return messages


def parse_byte_lookups(rom: bytes) -> tuple[list[int], list[bytes], int]:
    offsets: list[int] = []
    records: list[bytes] = []
    position = BYTE_LOOKUP_BASE
    for index in range(BYTE_LOOKUP_COUNT):
        size = rom[position]
        end = position + size
        if size < 2 or end > len(rom) or rom[end - 1] != 0xFF:
            raise ValueError(f"Malformed byte lookup {index} at 0x{position:06X}")
        offsets.append(position + 1 - BYTE_LOOKUP_BASE)
        records.append(bytes(rom[position + 1 : end - 1]))
        position = end
    return offsets, records, position


def parse_word_lookups(rom: bytes) -> tuple[list[bytes], int]:
    records: list[bytes] = []
    position = WORD_LOOKUP_BASE
    for index in range(WORD_LOOKUP_COUNT):
        size = rom[position]
        end = position + size
        if size < 3 or not size & 1 or end > len(rom):
            raise ValueError(f"Malformed word lookup {index} at 0x{position:06X}")
        codes = [
            int.from_bytes(rom[cursor : cursor + 2], "little")
            for cursor in range(position + 1, end, 2)
        ]
        if not codes or codes[-1] != 0x1C0 or any(code > 0xFF for code in codes[:-1]):
            raise ValueError(f"Word lookup {index} has invalid codes")
        records.append(bytes(codes[:-1]))
        position = end
    return records, position


def visible_lookup_text(raw: bytes) -> str:
    return decode_system(raw.rstrip(b"\xFF"))


def parse_ascii_lookups(rom: bytes) -> list[bytes]:
    """The dialogue/battle insertion tables are distinct from menu encoding."""
    records = []
    for table, count in ((ASCII_BYTE_POINTERS, BYTE_LOOKUP_COUNT), (ASCII_WORD_POINTERS, WORD_LOOKUP_COUNT)):
        for index in range(count):
            pointer = int.from_bytes(rom[table + index * 3:table + index * 3 + 3], "little")
            if pointer == 0xFFFFFF:
                records.append(b"")
                continue
            start = cpu_to_file(pointer)
            if not ASCII_START <= start < ASCII_LIMIT:
                raise ValueError(f"ASCII lookup {len(records)} points outside its text bank")
            end = rom.find(b"\xFF", start, ASCII_LIMIT)
            if end < 0:
                raise ValueError("Unterminated ASCII lookup")
            records.append(rom[start:end])
    return records


def write_ascii_lookups(output: bytearray, base: bytes, before: list[str], after: list[str]) -> None:
    records = parse_ascii_lookups(base)
    for index, (old, new) in enumerate(zip(before, after, strict=True)):
        if old != new:
            records[index] = new.encode("ascii").replace(b" ", b"\x01")
    output[ASCII_START:ASCII_LIMIT] = b"\xFF" * (ASCII_LIMIT - ASCII_START)
    position = ASCII_START
    ordinal = 0
    for table, count in ((ASCII_BYTE_POINTERS, BYTE_LOOKUP_COUNT), (ASCII_WORD_POINTERS, WORD_LOOKUP_COUNT)):
        for index in range(count):
            raw = records[ordinal]
            ordinal += 1
            pointer = 0xFFFFFF
            if raw:
                if position + len(raw) + 1 > ASCII_LIMIT:
                    raise ValueError("Dialogue/battle lookup names exceed their ASCII text bank")
                pointer = file_to_cpu(position)
                output[position:position + len(raw) + 1] = raw + b"\xFF"
                position += len(raw) + 1
            output[table + index * 3:table + index * 3 + 3] = pointer.to_bytes(3, "little")


def essential_controls(raw: bytes) -> tuple[int, ...]:
    return tuple(code for code in raw if code in STRUCTURAL_CONTROLS)


def dialogue_advances(rom: bytes) -> dict[str, int]:
    result: dict[str, int] = {}
    for code in range(0x21, 0x7F):
        raw = rom[
            DIALOGUE_FONT_BASE + code * DIALOGUE_FONT_BYTES_PER_GLYPH :
            DIALOGUE_FONT_BASE + (code + 1) * DIALOGUE_FONT_BYTES_PER_GLYPH
        ]
        occupied: list[int] = []
        for row in range(15):
            bits = int.from_bytes(raw[row * 2 : row * 2 + 2], "big")
            occupied.extend(column for column in range(16) if bits & (0x8000 >> column))
        result[chr(code)] = max(occupied) - min(occupied) + 1 if occupied else 0
    result[" "] = int.from_bytes(
        rom[SPACE_ADVANCE_IMMEDIATE_OFFSET : SPACE_ADVANCE_IMMEDIATE_OFFSET + 2],
        "little",
    ) + 1
    return result


def dialogue_metrics(raw: bytes, advances: dict[str, int]) -> dict[str, object]:
    widths: list[int] = []
    current = 0
    dynamic = False
    for code in raw:
        if code == 0xC0:
            widths.append(current)
            break
        if code in LINE_BOUNDARY_CONTROLS:
            widths.append(current)
            current = 0
        elif code in DYNAMIC_INSERT_CONTROLS:
            dynamic = True
        elif code == 0x01:
            current += advances[" "]
        elif 0x20 <= code <= 0x7E:
            current += advances[chr(code)]
    if not widths:
        widths.append(current)
    return {
        "encoded_bytes": len(raw),
        "literal_line_widths": widths,
        "max_literal_line_width": max(widths, default=0),
        "line_budget": DIALOGUE_LINE_BUDGET,
        "dynamic_insert_present": dynamic,
    }


def pack_message_layout(records: list[bytes]) -> tuple[list[int], int]:
    offsets: list[int] = []
    position = SCRIPT_START
    for ordinal, raw in enumerate(records):
        if len(raw) > 0x10000:
            raise ValueError(f"Message {ordinal:04X} exceeds one 64 KiB bank")
        bank_end = (position & ~0xFFFF) + 0x10000
        if position + len(raw) > bank_end:
            position = bank_end
        if position + len(raw) > SCRIPT_END:
            raise ValueError("Edited dialogue exceeds v1.2.9's two-bank EB-EC capacity")
        offsets.append(position)
        position += len(raw)
    return offsets, position


def parse_item_map(rom: bytes, lookup_offsets: list[int]) -> list[ItemMapEntry]:
    by_offset = {offset: index for index, offset in enumerate(lookup_offsets)}
    entries: list[ItemMapEntry] = []
    position = MENU_ALIAS_MAP_OFFSET
    while True:
        source = int.from_bytes(rom[position : position + 2], "little")
        if source == 0xFFFF:
            break
        block = rom[position + 2]
        count = rom[position + 3]
        if source not in by_offset:
            raise ValueError(f"Item map source 0x{source:04X} is not a lookup record")
        entries.append(ItemMapEntry(by_offset[source], block, count, position))
        position += 4
        if position + 4 > MENU_ALIAS_MAP_LIMIT:
            raise ValueError("Item map has no terminator")
    entries.sort(key=lambda item: item.block)
    if len(entries) != BATTLE_BLOCK_COUNT or [entry.block for entry in entries] != list(range(BATTLE_BLOCK_COUNT)):
        raise ValueError("v1.2.9 item block map is incomplete")
    return entries


def glyph(pattern: tuple[str, ...]) -> tuple[list[int], int]:
    width = len(pattern[0])
    if len(pattern) != 8 or any(len(row) != width for row in pattern):
        raise ValueError("Invalid glyph pattern")
    rows = [
        sum(1 << (width - column - 1) for column, pixel in enumerate(row) if pixel == "#")
        for row in pattern
    ]
    return rows, width + 1


LOWER_T_4 = glyph((".#..", ".#..", "###.", ".#..", ".#..", ".#.#", "..##", "...."))
LOWER_T_3 = glyph((".#.", ".#.", "###", ".#.", ".#.", ".##", ".##", "..."))
CAPITAL_I_2 = glyph(("##", "#.", "#.", "#.", "#.", "#.", "##", ".."))
CAPITAL_T_2 = glyph(("##", "#.", "#.", "#.", "#.", "#.", "#.", ".."))
LOWER_F_4 = glyph((".##.", ".#.#", ".#..", "###.", ".#..", ".#..", ".#..", "...."))
LOWER_F_3 = glyph((".##", ".#.", ".#.", "###", ".#.", ".#.", ".#.", "..."))
LOWER_F_2 = glyph((".#", "#.", "#.", "##", "#.", "#.", "#.", ".."))


def proportional_glyph(rows: list[int], character: str, max_width: int) -> tuple[list[int], int]:
    if character == " ":
        return [0] * 8, 2
    occupied = [
        column for column in range(8)
        if any(row & (0x80 >> column) for row in rows)
    ]
    if not occupied:
        return [0] * 8, 2
    left, right = min(occupied), max(occupied)
    source_width = right - left + 1
    target_width = min(source_width, max_width)
    output: list[int] = []
    for row in rows:
        source_bits = [
            int(bool(row & (0x80 >> (left + column))))
            for column in range(source_width)
        ]
        packed = 0
        for column in range(target_width):
            source_column = (
                round(column * (source_width - 1) / (target_width - 1))
                if target_width > 1 else source_width // 2
            )
            if source_bits[source_column]:
                packed |= 1 << (target_width - column - 1)
        output.append(packed)
    return output, target_width + 1


def build_field_glyph_sets(rom: bytes) -> dict[int, dict[str, tuple[list[int], int]]]:
    raw = {
        character: [
            rom[SYSTEM_FONT_OFFSET + code * SYSTEM_FONT_BYTES_PER_GLYPH + row * 2]
            for row in range(8)
        ]
        for character, code in SYSTEM_REVERSE.items()
    }
    current = {
        width: {character: proportional_glyph(rows, character, width) for character, rows in raw.items()}
        for width in (5, 4, 3, 2, 1)
    }
    repaired = {width: dict(glyphs) for width, glyphs in current.items()}
    repaired[4].update({"I": current[5]["I"], "T": current[5]["T"], "W": current[5]["W"], "t": LOWER_T_4, "m": current[5]["m"], "w": current[5]["w"], "f": LOWER_F_4})
    repaired[3].update({"t": LOWER_T_3, "f": LOWER_F_3})
    for width in (3, 2, 1):
        repaired[width].update({"m": current[5]["m"], "w": current[5]["w"], "W": current[5]["W"]})
    repaired[2].update({"I": CAPITAL_I_2, "T": CAPITAL_T_2, "f": LOWER_F_2})
    for width in (4, 3, 2, 1):
        repaired[width]["M"] = current[5]["M"]
    # v1.2.3 connected these strokes without changing widths or spacing.
    for width, shapes in {
        3: {"K": [5, 5, 6, 6, 6, 5, 5, 0], "Z": [7, 1, 1, 2, 4, 4, 7, 0]},
        4: {"K": [9, 10, 12, 12, 12, 10, 9, 0], "Z": [15, 1, 2, 2, 4, 8, 15, 0]},
    }.items():
        for character, rows in shapes.items():
            repaired[width][character] = (rows, width + 1)
    return repaired


def build_battle_glyphs(rom: bytes) -> dict[str, tuple[list[int], int]]:
    raw = {
        character: [
            rom[SYSTEM_FONT_OFFSET + code * SYSTEM_FONT_BYTES_PER_GLYPH + row * 2]
            for row in range(8)
        ]
        for character, code in SYSTEM_REVERSE.items()
    }
    result = {character: proportional_glyph(rows, character, 4) for character, rows in raw.items()}
    result.update({
        "I": proportional_glyph(raw["I"], "I", 5),
        "T": proportional_glyph(raw["T"], "T", 5),
        "W": proportional_glyph(raw["W"], "W", 5),
        "M": proportional_glyph(raw["M"], "M", 5),
        "f": LOWER_F_4,
        "t": LOWER_T_4,
        "m": proportional_glyph(raw["m"], "m", 5),
        "w": proportional_glyph(raw["w"], "w", 5),
    })
    result["K"] = ([9, 10, 12, 12, 12, 10, 9, 0], 5)
    result["Z"] = ([15, 1, 2, 2, 4, 8, 15, 0], 5)
    return result


def render_proportional(text: str, glyphs: dict[str, tuple[list[int], int]]) -> tuple[list[list[int]], int]:
    pixels: list[list[int]] = [[] for _ in range(8)]
    width = 0
    for character in text:
        try:
            rows, advance = glyphs[character]
        except KeyError as error:
            raise ValueError(f"Menu character {character!r} is not supported by v1.2.9") from error
        glyph_width = max(0, advance - 1)
        for row_index, bits in enumerate(rows):
            pixels[row_index].extend(
                (bits >> (glyph_width - column - 1)) & 1
                for column in range(glyph_width)
            )
            pixels[row_index].extend([0] * (advance - glyph_width))
        width += advance
    chunks: list[list[int]] = []
    for start in range(0, width, 8):
        chunk_rows: list[int] = []
        for row in pixels:
            packed = 0
            for column in range(8):
                position = start + column
                if position < len(row) and row[position]:
                    packed |= 0x80 >> column
            chunk_rows.append(packed)
        chunks.append(chunk_rows)
    return chunks, width


def tile_bytes(rows: Iterable[int]) -> bytes:
    return b"".join(bytes((row, 0xFF)) for row in rows)


def render_field_label(text: str, glyph_sets: dict[int, dict[str, tuple[list[int], int]]]) -> tuple[list[list[int]], int, int, bool]:
    for width in (4, 3, 2):
        chunks, pixels = render_proportional(text, glyph_sets[width])
        if len(chunks) <= PROPORTIONAL_TILES_PER_SLOT:
            return chunks, pixels, width, False
        if pixels == PROPORTIONAL_TILES_PER_SLOT * 8 + 1 and chunks and not any(chunks[-1]):
            return chunks[:-1], pixels - 1, width, True
    raise ValueError(f"Field/Shop/Storage item label {text!r} exceeds 64 pixels")


def render_battle_label(text: str, glyphs: dict[str, tuple[list[int], int]]) -> tuple[list[list[int]], int, bool]:
    if not 1 <= len(text) <= 8:
        raise ValueError(f"Battle item label {text!r} must contain 1-8 characters")
    if "'" in text:
        raise ValueError(f"Battle item label {text!r} cannot use an apostrophe")
    chunks, pixels = render_proportional(text, glyphs)
    if len(chunks) > BATTLE_NAME_TILE_LIMIT:
        if pixels == BATTLE_NAME_TILE_LIMIT * 8 + 1 and chunks and not any(chunks[-1]):
            return chunks[:-1], pixels - 1, True
        raise ValueError(f"Battle item label {text!r} exceeds 40 pixels")
    return chunks, pixels, False


def render_spell_label(text: str, glyph_sets: dict[int, dict[str, tuple[list[int], int]]], final_row: bool) -> tuple[list[list[int]], int, int, bool]:
    widths = (3,) if final_row else (4, 3, 2, 1)
    tile_limit = 2 if final_row else SPELL_TILES_PER_BLOCK
    for width in widths:
        chunks, pixels = render_proportional(text, glyph_sets[width])
        if len(chunks) <= tile_limit:
            return chunks, pixels, width, False
        if pixels == tile_limit * 8 + 1 and chunks and not any(chunks[-1]):
            return chunks[:-1], pixels - 1, width, True
    raise ValueError(
        f"Magic label {text!r} exceeds {'16' if final_row else '32'} pixels"
    )


class RelativeBranchBuilder:
    def __init__(self) -> None:
        self.code = bytearray()
        self.labels: dict[str, int] = {}
        self.branches: list[tuple[int, str]] = []

    def emit(self, *values: int) -> None:
        self.code.extend(values)

    def label(self, name: str) -> None:
        self.labels[name] = len(self.code)

    def branch(self, opcode: int, target: str) -> None:
        self.emit(opcode, 0)
        self.branches.append((len(self.code) - 1, target))

    def finish(self) -> bytes:
        for operand, target in self.branches:
            displacement = self.labels[target] - (operand + 1)
            if not -128 <= displacement <= 127:
                raise ValueError(f"Status alias branch to {target} is out of range")
            self.code[operand] = displacement & 0xFF
        return bytes(self.code)


def build_status_assets(aliases: dict[int, str]) -> tuple[bytes, bytes]:
    data = bytearray()
    offsets: dict[int, int] = {}
    for index, alias in aliases.items():
        offsets[index] = STATUS_ALIAS_DATA_OFFSET + len(data) - BYTE_LOOKUP_BASE
        data += compile_system(alias) + b"\xFF"
    if STATUS_ALIAS_DATA_OFFSET + len(data) > STATUS_RESERVED_END:
        raise ValueError("Status aliases exceed their F5:2200-F5:23FF reservation")
    assembler = RelativeBranchBuilder()
    assembler.emit(0x08, 0xC2, 0x30)
    for index in aliases:
        assembler.emit(0xC9, *index.to_bytes(2, "little"))
        assembler.branch(0xF0, f"alias_{index}")
    assembler.emit(0x28, 0x5C, 0x00, 0x20, 0xF5)
    for index in aliases:
        assembler.label(f"alias_{index}")
        assembler.emit(0xA2, *offsets[index].to_bytes(2, "little"), 0x28, 0x6B)
    routine = assembler.finish()
    if STATUS_ROUTINE_OFFSET + len(routine) > STATUS_ALIAS_DATA_OFFSET:
        raise ValueError("Status alias resolver exceeds its F5:2100-F5:21FF reservation")
    return routine, bytes(data)


def resolve_menu_text(row: dict[str, str], selected_full: str) -> str:
    replacement = row.get("replacement_menu_text", "")
    if replacement == "<FULL>":
        return selected_full
    if replacement == "<EMPTY>":
        return ""
    if replacement != "":
        return replacement
    if row["behavior"] == "follow_full":
        return selected_full
    return row["current_menu_text"]


def parse_index(value: str | int | float) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return int(value, 0) if value.lower().startswith("0x") else int(float(value))


def load_manifest(path: Path | None = None) -> dict[str, object]:
    manifest_path = path or Path(__file__).with_name("translation_manifest.json")
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def validate_project(project: dict[str, list[dict[str, str]]], manifest: dict[str, object], rom: bytes) -> None:
    messages = extract_messages(rom)
    dialogue = project["dialogue"]
    if len(dialogue) != MESSAGE_COUNT:
        raise ValueError(f"Workbook has {len(dialogue)} dialogue rows; expected {MESSAGE_COUNT}")
    manifest_dialogue = manifest["dialogue"]
    for ordinal, (row, current) in enumerate(zip(dialogue, messages, strict=True)):
        expected_id = f"0x{ordinal:04X}"
        if row.get("message_id") != expected_id:
            raise ValueError(f"Dialogue row {ordinal + 2} has ID {row.get('message_id')!r}; expected {expected_id}")
        if row.get("english_reference", "") != current.text:
            raise ValueError(f"Dialogue reference {expected_id} was edited; use replacement_text instead")
        canonical = manifest_dialogue[expected_id]
        if row.get("control_signature", "") != canonical["control_signature"]:
            raise ValueError(f"Dialogue control signature {expected_id} was edited")

    byte_offsets, byte_records, _ = parse_byte_lookups(rom)
    del byte_offsets
    word_records, _ = parse_word_lookups(rom)
    lookup_rows = project["lookups"]
    if len(lookup_rows) != BYTE_LOOKUP_COUNT + WORD_LOOKUP_COUNT:
        raise ValueError("Workbook lookup row count is not 358")
    references = [visible_lookup_text(raw) for raw in byte_records] + [decode_system(raw) for raw in word_records]
    for ordinal, (row, reference) in enumerate(zip(lookup_rows, references, strict=True)):
        table = "byte" if ordinal < BYTE_LOOKUP_COUNT else "word"
        index = ordinal if table == "byte" else ordinal - BYTE_LOOKUP_COUNT
        if row.get("table") != table or parse_index(row.get("index", "-1")) != index:
            raise ValueError(f"Lookup row {ordinal + 2} is out of order")
        if row.get("english_reference", "") != reference:
            raise ValueError(f"Lookup reference {table}:{index} was edited; use replacement_text instead")

    canonical_menu = manifest["menu_text"]
    if len(project["menu_text"]) != len(canonical_menu):
        raise ValueError("Menu Text row count does not match the release")
    seen: set[str] = set()
    for row in project["menu_text"]:
        key = f"{row.get('context')}:{parse_index(row.get('lookup_index', '-1'))}"
        if key not in canonical_menu:
            raise ValueError(f"Unexpected Menu Text row {key}")
        if key in seen:
            raise ValueError(f"Duplicate Menu Text row {key}")
        expected = canonical_menu[key]
        for field in ("context", "lookup_index", "current_full_text", "current_menu_text", "behavior", "width_limit"):
            actual = str(row.get(field, ""))
            wanted = str(expected[field])
            if field == "lookup_index":
                actual = str(parse_index(actual))
            if actual != wanted:
                raise ValueError(f"Menu Text baseline field {key}/{field} was edited")
        seen.add(key)
    if seen != set(canonical_menu):
        missing = sorted(set(canonical_menu) - seen)
        raise ValueError(f"Workbook is missing Menu Text rows, beginning with {missing[0]}")


def selected_lookup_texts(project: dict[str, list[dict[str, str]]]) -> tuple[list[str], list[str]]:
    byte: list[str] = []
    word: list[str] = []
    for row in project["lookups"]:
        replacement = row.get("replacement_text", "")
        selected = replacement if replacement != "" else row["english_reference"]
        if selected == "<EMPTY>":
            selected = ""
        (byte if row["table"] == "byte" else word).append(selected)
    return byte, word


def menu_rows_by_key(project: dict[str, list[dict[str, str]]]) -> dict[tuple[str, int], dict[str, str]]:
    return {
        (row["context"], parse_index(row["lookup_index"])): row
        for row in project["menu_text"]
    }


def build_field_assets(
    rom: bytes,
    entries: list[ItemMapEntry],
    selected_full: list[str],
    menu_rows: dict[tuple[str, int], dict[str, str]],
) -> tuple[bytes, bytes, list[dict[str, object]]]:
    glyph_sets = build_field_glyph_sets(rom)
    blank = tile_bytes([0] * 8)
    blocks = bytearray()
    counts = bytearray()
    report: list[dict[str, object]] = []
    for entry in entries:
        row = menu_rows[("field_item", entry.lookup_index)]
        label = resolve_menu_text(row, selected_full[entry.lookup_index])
        if not label:
            raise ValueError(f"Field item lookup {entry.lookup_index} has an empty label")
        if label == row["current_menu_text"]:
            counts.append(entry.count)
            start = PROPORTIONAL_TILE_DATA_OFFSET + entry.block * PROPORTIONAL_TILE_BLOCK_BYTES
            blocks += rom[start:start + PROPORTIONAL_TILE_BLOCK_BYTES]
            report.append({"lookup_index": entry.lookup_index, "label": label, "tiles": entry.count, "reused_original_art": True})
            continue
        chunks, pixels, width, trimmed = render_field_label(label, glyph_sets)
        counts.append(len(chunks))
        blocks += b"".join(tile_bytes(chunk) for chunk in chunks)
        blocks += blank * (PROPORTIONAL_TILES_PER_SLOT - len(chunks))
        report.append({"lookup_index": entry.lookup_index, "label": label, "pixels": pixels, "tiles": len(chunks), "glyph_width": width, "trimmed_final_gap": trimmed})
    return bytes(counts), bytes(blocks), report


def build_battle_assets(
    rom: bytes,
    entries: list[ItemMapEntry],
    selected_full: list[str],
    menu_rows: dict[tuple[str, int], dict[str, str]],
) -> tuple[bytes, bytes, list[dict[str, object]]]:
    glyphs = build_battle_glyphs(rom)
    blank = tile_bytes([0] * 8)
    blocks = bytearray()
    counts = bytearray()
    report: list[dict[str, object]] = []
    for entry in entries:
        row = menu_rows[("battle_item", entry.lookup_index)]
        label = resolve_menu_text(row, selected_full[entry.lookup_index])
        if label == row["current_menu_text"]:
            counts.append(rom[BATTLE_COUNT_TABLE_OFFSET + entry.block])
            start = BATTLE_TILE_DATA_OFFSET + entry.block * BATTLE_TILES_PER_BLOCK * 16
            blocks += rom[start:start + BATTLE_TILES_PER_BLOCK * 16]
            report.append({"lookup_index": entry.lookup_index, "label": label, "tiles": counts[-1], "reused_original_art": True})
            continue
        chunks, pixels, trimmed = render_battle_label(label, glyphs)
        counts.append(len(chunks))
        blocks += b"".join(tile_bytes(chunk) for chunk in chunks)
        blocks += blank * (BATTLE_TILES_PER_BLOCK - len(chunks))
        report.append({"lookup_index": entry.lookup_index, "label": label, "pixels": pixels, "tiles": len(chunks), "trimmed_final_gap": trimmed})
    return bytes(counts), bytes(blocks), report


def build_packed_battle_assets(rom: bytes) -> dict[int, bytes]:
    """Rebuild both v1.2.9 caches from current ED name tiles and native glyphs.

    Every item block keeps its fixed 256-byte pitch. Tiles between the six
    name tiles are native font glyphs, not empty space or another name.
    No renderer code, slot mapping, count or timing constant is changed.
    """
    if len(rom) != ROM_SIZE:
        raise ValueError("Packed Battle assets require a 4 MiB ROM")
    slots = [tuple(int.from_bytes(rom[j:j + 2], "little")
                   for j in range(BATTLE_SLOT_TABLE_OFFSET + slot * 12,
                                  BATTLE_SLOT_TABLE_OFFSET + (slot + 1) * 12, 2))
             for slot in range(12)]
    occupied = {code for codes in slots for code in codes}
    magic = {int.from_bytes(rom[j:j + 2], "little")
             for j in range(0x352480, 0x352510, 2)}
    result = {}
    for slot, destination, expected_codes in BATTLE_PACKED_SLOTS:
        codes = slots[slot]
        if codes != expected_codes:
            raise ValueError(f"Unsupported packed Battle slot {slot} layout")
        first, last = min(codes), max(codes)
        gaps = set(range(first, last + 1)) - set(codes)
        if gaps & (occupied | magic):
            raise ValueError(f"Packed Battle slot {slot} overlaps another menu cache")
        payload = bytearray(b"\xFF" * (BATTLE_BLOCK_COUNT * BATTLE_PACKED_PITCH))
        for block in range(BATTLE_BLOCK_COUNT):
            source = BATTLE_TILE_DATA_OFFSET + block * BATTLE_TILES_PER_BLOCK * 16
            span = bytearray(rom[SYSTEM_FONT_OFFSET + first * 16:
                                 SYSTEM_FONT_OFFSET + (last + 1) * 16])
            for tile, code in enumerate(codes):
                offset = (code - first) * 16
                span[offset:offset + 16] = rom[source + tile * 16:source + (tile + 1) * 16]
            start = block * BATTLE_PACKED_PITCH
            payload[start:start + len(span)] = span
        result[destination] = bytes(payload)
    return result


def build_spell_assets(
    rom: bytes,
    selected_full: list[str],
    menu_rows: dict[tuple[str, int], dict[str, str]],
) -> tuple[bytes, bytes, list[dict[str, object]]]:
    glyph_sets = build_field_glyph_sets(rom)
    blank = tile_bytes([0] * 8)
    mapping = bytearray()
    blocks = bytearray()
    report: list[dict[str, object]] = []
    for index in range(SPELL_LOOKUP_FIRST, SPELL_LOOKUP_LAST + 1):
        row = menu_rows[("magic", index)]
        label = resolve_menu_text(row, selected_full[index])
        if not label:
            mapping += b"\xFF\xFF"
            continue
        old_map = SPELL_MAP_OFFSET + (index - SPELL_LOOKUP_FIRST) * 2
        if label == row["current_menu_text"]:
            block, count = rom[old_map:old_map + 2]
            if block == 255:
                raise ValueError(f"Nonempty Magic label {index} has no original artwork")
            mapping += bytes((len(report), count))
            start = SPELL_TILE_DATA_OFFSET + block * SPELL_TILE_BLOCK_BYTES
            blocks += rom[start:start + SPELL_TILE_BLOCK_BYTES]
            report.append({"lookup_index": index, "label": label, "tiles": count, "block": len(report), "reused_original_art": True})
            continue
        chunks, pixels, width, trimmed = render_spell_label(
            label, glyph_sets, index == SPELL_FINAL_ROW_INDEX
        )
        block = len(report)
        if SPELL_TILE_DATA_OFFSET + (block + 1) * SPELL_TILE_BLOCK_BYTES > SPELL_TILE_DATA_LIMIT:
            raise ValueError("Magic labels exceed the reserved pre-rendered block capacity")
        mapping += bytes((block, len(chunks)))
        blocks += b"".join(tile_bytes(chunk) for chunk in chunks)
        blocks += blank * (SPELL_TILES_PER_BLOCK - len(chunks))
        report.append({"lookup_index": index, "label": label, "block": block, "pixels": pixels, "tiles": len(chunks), "glyph_width": width, "trimmed_final_gap": trimmed})
    return bytes(mapping), bytes(blocks), report


def selected_status_aliases(
    selected_full: list[str], menu_rows: dict[tuple[str, int], dict[str, str]]
) -> dict[int, str]:
    aliases: dict[int, str] = {}
    for index in range(SPELL_LOOKUP_FIRST, SPELL_LOOKUP_LAST + 1):
        row = menu_rows[("status", index)]
        display = resolve_menu_text(row, selected_full[index])
        if not display:
            continue
        limit = 9 if index < 160 else 7
        if len(compile_system(display)) > limit:
            raise ValueError(f"Status label {display!r} for lookup {index} exceeds {limit} cells")
        if display != selected_full[index]:
            aliases[index] = display
    return aliases


def update_checksum(rom: bytearray) -> tuple[int, int]:
    rom[CHECKSUM_OFFSET : CHECKSUM_OFFSET + 4] = b"\x00\x00\x00\x00"
    checksum = (sum(rom) + 510) & 0xFFFF
    complement = checksum ^ 0xFFFF
    rom[CHECKSUM_OFFSET : CHECKSUM_OFFSET + 2] = complement.to_bytes(2, "little")
    rom[CHECKSUM_OFFSET + 2 : CHECKSUM_OFFSET + 4] = checksum.to_bytes(2, "little")
    if sum(rom) & 0xFFFF != checksum:
        raise ValueError("SNES checksum verification failed")
    return complement, checksum


def compile_project(
    base: bytes,
    project: dict[str, list[dict[str, str]]],
    manifest: dict[str, object],
    *,
    allow_control_changes: bool = False,
) -> tuple[bytes, dict[str, object]]:
    if len(base) != ROM_SIZE or sha256(base) != RELEASE_SHA256:
        raise ValueError("compile_project requires the exact frozen v1.2.9 ROM")
    validate_project(project, manifest, base)
    output = bytearray(base)
    messages = extract_messages(base)
    advances = dialogue_advances(base)

    selected_messages: list[bytes] = []
    changed_messages = 0
    dialogue_warnings: list[dict[str, object]] = []
    for row, current in zip(project["dialogue"], messages, strict=True):
        replacement = row.get("replacement_text", "")
        selected_text = replacement if replacement != "" else current.text
        raw = compile_main(selected_text)
        if current.ordinal in BATTLE_QUEUE_SINGLE_LINE_IDS and any(code in (0xC3, 0xC8) for code in raw):
            raise ValueError(f"Battle notice {current.ordinal:04X} must remain one line")
        if not allow_control_changes and essential_controls(raw) != essential_controls(current.raw):
            raise ValueError(
                f"Message 0x{current.ordinal:04X} changes structural controls; "
                "restore its tags or explicitly allow control changes"
            )
        metrics = dialogue_metrics(raw, advances)
        if current.ordinal in BATTLE_QUEUE_SINGLE_LINE_IDS:
            literal_cells = sum(code == 1 or 0x20 <= code <= 0x7E for code in raw)
            if replacement and literal_cells > 31:
                raise ValueError(f"Battle notice {current.ordinal:04X} has {literal_cells} literal cells; limit 31 before dynamic inserts")
        if current.ordinal not in BATTLE_QUEUE_SINGLE_LINE_IDS and metrics["max_literal_line_width"] > DIALOGUE_LINE_BUDGET:
            raise ValueError(
                f"Message 0x{current.ordinal:04X} has a literal line width of "
                f"{metrics['max_literal_line_width']} units (limit {DIALOGUE_LINE_BUDGET})"
            )
        if metrics["dynamic_insert_present"] and replacement:
            dialogue_warnings.append({"message_id": f"0x{current.ordinal:04X}", "warning": "dynamic insert width requires emulator QA"})
        changed_messages += raw != current.raw
        selected_messages.append(raw)

    current_end = max(message.offset + len(message.raw) for message in messages)
    if any(not SCRIPT_START <= message.offset < message.offset + len(message.raw) <= SCRIPT_END for message in messages):
        raise ValueError("Dialogue points outside the reserved EB-EC text banks")
    selected_end = current_end
    if changed_messages:
        if all(len(raw) <= len(message.raw) for raw, message in zip(selected_messages, messages, strict=True)):
            for raw, message in zip(selected_messages, messages, strict=True):
                if raw != message.raw:
                    output[message.offset:message.offset + len(message.raw)] = raw + b"\xC0" * (len(message.raw) - len(raw))
        else:
            selected_offsets, selected_end = pack_message_layout(selected_messages)
            output[SCRIPT_START:SCRIPT_END] = b"\xFF" * (SCRIPT_END - SCRIPT_START)
            for ordinal, (offset, raw) in enumerate(zip(selected_offsets, selected_messages, strict=True)):
                output[offset:offset + len(raw)] = raw
                entry = POINTER_TABLE + ordinal * 3
                output[entry:entry + 3] = file_to_cpu(offset).to_bytes(3, "little")

    old_offsets, old_byte_records, old_byte_end = parse_byte_lookups(base)
    old_word_records, old_word_end = parse_word_lookups(base)
    selected_byte_text, selected_word_text = selected_lookup_texts(project)
    selected_byte_records = [compile_system(text) for text in selected_byte_text]
    selected_word_records = [compile_system(text) for text in selected_word_text]
    old_byte_text = [visible_lookup_text(raw) for raw in old_byte_records]
    old_word_text = [decode_system(raw) for raw in old_word_records]
    changed_byte = sum(old != new for old, new in zip(old_byte_text, selected_byte_text, strict=True))
    changed_word = sum(old != new for old, new in zip(old_word_text, selected_word_text, strict=True))
    menu_rows = menu_rows_by_key(project)
    baseline_menu_rows = {
        key: {**row, "replacement_menu_text": ""}
        for key, row in menu_rows.items()
    }
    menu_changes = sum(bool(row.get("replacement_menu_text", "")) for row in project["menu_text"])

    item_report: list[dict[str, object]] = []
    battle_report: list[dict[str, object]] = []
    spell_report: list[dict[str, object]] = []
    status_aliases: dict[int, str] = {}
    new_byte_end = old_byte_end
    new_word_end = old_word_end

    if changed_byte:
        payload = bytearray()
        new_offsets: list[int] = []
        for index, raw in enumerate(selected_byte_records):
            if len(raw) > 0xFD:
                raise ValueError(f"Byte lookup {index} exceeds 253 encoded characters")
            new_offsets.append(len(payload) + 1)
            payload += bytes((len(raw) + 2,)) + raw + b"\xFF"
        new_byte_end = BYTE_LOOKUP_BASE + len(payload)
        if new_byte_end > BYTE_LOOKUP_LIMIT:
            raise ValueError(
                f"Byte lookup table needs {len(payload)} bytes; v1.2.9 reserves only "
                f"{BYTE_LOOKUP_LIMIT - BYTE_LOOKUP_BASE} bytes"
            )
        output[BYTE_LOOKUP_BASE:BYTE_LOOKUP_LIMIT] = b"\xFF" * (BYTE_LOOKUP_LIMIT - BYTE_LOOKUP_BASE)
        output[BYTE_LOOKUP_BASE:new_byte_end] = payload

    item_related = changed_byte or any(
        row.get("replacement_menu_text", "")
        for row in project["menu_text"]
        if row["context"] in ("field_item", "battle_item")
    )
    if item_related:
        entries = parse_item_map(base, old_offsets)
        baseline_field_counts, baseline_field, _ = build_field_assets(
            base, entries, old_byte_text, baseline_menu_rows
        )
        baseline_battle_counts, baseline_battle, _ = build_battle_assets(
            base, entries, old_byte_text, baseline_menu_rows
        )
        if any(base[entry.position + 3] != baseline_field_counts[entry.block] for entry in entries):
            raise ValueError("v1.2.9 item count reconstruction gate failed")
        for offset in (PROPORTIONAL_TILE_DATA_OFFSET, STORAGE_TILE_DATA_OFFSET, SHOP_TILE_DATA_OFFSET):
            if base[offset : offset + len(baseline_field)] != baseline_field:
                raise ValueError("v1.2.9 field item-art reconstruction gate failed")
        if base[BATTLE_COUNT_TABLE_OFFSET : BATTLE_COUNT_TABLE_OFFSET + len(baseline_battle_counts)] != baseline_battle_counts or base[BATTLE_TILE_DATA_OFFSET : BATTLE_TILE_DATA_OFFSET + len(baseline_battle)] != baseline_battle:
            raise ValueError("v1.2.9 Battle item-art reconstruction gate failed")

        field_counts, field_blocks, item_report = build_field_assets(base, entries, selected_byte_text, menu_rows)
        battle_counts, battle_blocks, battle_report = build_battle_assets(base, entries, selected_byte_text, menu_rows)
        for entry in entries:
            if changed_byte:
                output[entry.position : entry.position + 2] = new_offsets[entry.lookup_index].to_bytes(2, "little")
            output[entry.position + 3] = field_counts[entry.block]
        for offset in (PROPORTIONAL_TILE_DATA_OFFSET, STORAGE_TILE_DATA_OFFSET, SHOP_TILE_DATA_OFFSET):
            output[offset : offset + len(field_blocks)] = field_blocks
        output[STORAGE_COUNT_TABLE_OFFSET : STORAGE_COUNT_TABLE_OFFSET + len(field_counts)] = field_counts
        output[SHOP_COUNT_TABLE_OFFSET : SHOP_COUNT_TABLE_OFFSET + len(field_counts)] = field_counts
        output[BATTLE_COUNT_TABLE_OFFSET : BATTLE_COUNT_TABLE_OFFSET + len(battle_counts)] = battle_counts
        output[BATTLE_TILE_DATA_OFFSET : BATTLE_TILE_DATA_OFFSET + len(battle_blocks)] = battle_blocks

    if changed_word:
        payload = bytearray()
        for index, raw in enumerate(selected_word_records):
            size = 1 + 2 * (len(raw) + 1)
            if size > 0xFF:
                raise ValueError(f"Word lookup {index} exceeds 126 encoded characters")
            payload.append(size)
            for code in raw:
                payload += code.to_bytes(2, "little")
            payload += (0x1C0).to_bytes(2, "little")
        new_word_end = WORD_LOOKUP_BASE + len(payload)
        if new_word_end > WORD_LOOKUP_LIMIT:
            raise ValueError("Word lookup table exceeds its F6 reservation")
        output[WORD_LOOKUP_BASE:max(old_word_end, new_word_end)] = b"\xFF" * (max(old_word_end, new_word_end) - WORD_LOOKUP_BASE)
        output[WORD_LOOKUP_BASE:new_word_end] = payload

    spell_related = any(
        old_byte_text[index] != selected_byte_text[index]
        for index in range(SPELL_LOOKUP_FIRST, SPELL_LOOKUP_LAST + 1)
    ) or any(row.get("replacement_menu_text", "") for row in project["menu_text"] if row["context"] in ("magic", "status"))
    if spell_related:
        baseline_map, baseline_blocks, _ = build_spell_assets(
            base, old_byte_text, baseline_menu_rows
        )
        current_block_end = SPELL_TILE_DATA_OFFSET + len(baseline_blocks)
        if base[SPELL_MAP_OFFSET : SPELL_MAP_OFFSET + len(baseline_map)] != baseline_map or base[SPELL_TILE_DATA_OFFSET:current_block_end] != baseline_blocks:
            raise ValueError("v1.2.9 Magic-art reconstruction gate failed")
        spell_map, spell_blocks, spell_report = build_spell_assets(base, selected_byte_text, menu_rows)
        output[SPELL_MAP_OFFSET : SPELL_MAP_OFFSET + len(spell_map)] = spell_map
        output[SPELL_TILE_DATA_OFFSET:SPELL_TILE_DATA_LIMIT] = b"\xFF" * (SPELL_TILE_DATA_LIMIT - SPELL_TILE_DATA_OFFSET)
        output[SPELL_TILE_DATA_OFFSET : SPELL_TILE_DATA_OFFSET + len(spell_blocks)] = spell_blocks

        baseline_aliases = selected_status_aliases(old_byte_text, baseline_menu_rows)
        baseline_routine, baseline_data = build_status_assets(baseline_aliases)
        if base[STATUS_LOOKUP_HOOK_OFFSET : STATUS_LOOKUP_HOOK_OFFSET + 4] != STATUS_LOOKUP_CALL or base[STATUS_ROUTINE_OFFSET : STATUS_ROUTINE_OFFSET + len(baseline_routine)] != baseline_routine or base[STATUS_ALIAS_DATA_OFFSET : STATUS_ALIAS_DATA_OFFSET + len(baseline_data)] != baseline_data:
            raise ValueError("v1.2.9 Status-alias reconstruction gate failed")
        status_aliases = selected_status_aliases(selected_byte_text, menu_rows)
        routine, data = build_status_assets(status_aliases)
        output[STATUS_ROUTINE_OFFSET:STATUS_RESERVED_END] = b"\xFF" * (STATUS_RESERVED_END - STATUS_ROUTINE_OFFSET)
        output[STATUS_ROUTINE_OFFSET : STATUS_ROUTINE_OFFSET + len(routine)] = routine
        output[STATUS_ALIAS_DATA_OFFSET : STATUS_ALIAS_DATA_OFFSET + len(data)] = data

    if changed_byte or changed_word:
        write_ascii_lookups(output, base, old_byte_text + old_word_text, selected_byte_text + selected_word_text)

    # Validate the frozen layout, then rebuild from the *edited* ED tiles.
    # Run on every build, including no-op/dialogue-only builds, so stale
    # duplicate artwork can never be silently shipped.
    original_packed = build_packed_battle_assets(base)
    packed_blocks_changed = 0
    for offset, payload in build_packed_battle_assets(output).items():
        original = original_packed[offset]
        if base[offset:offset + len(original)] != original:
            raise ValueError("v1.2.9 packed Battle asset reconstruction gate failed")
        packed_blocks_changed += sum(
            payload[j:j + BATTLE_PACKED_PITCH] != original[j:j + BATTLE_PACKED_PITCH]
            for j in range(0, len(payload), BATTLE_PACKED_PITCH)
        )
        output[offset:offset + len(payload)] = payload

    allowed_regions = [
        (POINTER_TABLE, POINTER_TABLE + MESSAGE_COUNT * 3), (SCRIPT_START, SCRIPT_END),
        (BYTE_LOOKUP_BASE, BYTE_LOOKUP_LIMIT), (WORD_LOOKUP_BASE, WORD_LOOKUP_LIMIT),
        (ASCII_BYTE_POINTERS, ASCII_BYTE_POINTERS + BYTE_LOOKUP_COUNT * 3),
        (ASCII_WORD_POINTERS, ASCII_WORD_POINTERS + WORD_LOOKUP_COUNT * 3), (ASCII_START, ASCII_LIMIT),
        (MENU_ALIAS_MAP_OFFSET, MENU_ALIAS_MAP_OFFSET + BATTLE_BLOCK_COUNT * 4),
        (PROPORTIONAL_TILE_DATA_OFFSET, PROPORTIONAL_TILE_DATA_OFFSET + BATTLE_BLOCK_COUNT * 128),
        (STORAGE_TILE_DATA_OFFSET, STORAGE_TILE_DATA_OFFSET + BATTLE_BLOCK_COUNT * 128),
        (SHOP_TILE_DATA_OFFSET, SHOP_TILE_DATA_OFFSET + BATTLE_BLOCK_COUNT * 128),
        (STORAGE_COUNT_TABLE_OFFSET, STORAGE_COUNT_TABLE_OFFSET + BATTLE_BLOCK_COUNT),
        (SHOP_COUNT_TABLE_OFFSET, SHOP_COUNT_TABLE_OFFSET + BATTLE_BLOCK_COUNT),
        (BATTLE_COUNT_TABLE_OFFSET, BATTLE_COUNT_TABLE_OFFSET + BATTLE_BLOCK_COUNT),
        (BATTLE_TILE_DATA_OFFSET, BATTLE_TILE_DATA_OFFSET + BATTLE_BLOCK_COUNT * BATTLE_TILES_PER_BLOCK * 16),
        (SPELL_MAP_OFFSET, SPELL_MAP_OFFSET + (SPELL_LOOKUP_LAST - SPELL_LOOKUP_FIRST + 1) * 2),
        (SPELL_TILE_DATA_OFFSET, SPELL_TILE_DATA_LIMIT), (STATUS_ROUTINE_OFFSET, STATUS_RESERVED_END),
        (CHECKSUM_OFFSET, CHECKSUM_OFFSET + 4),
    ]
    # Only name tiles in the packed copies may change. The interleaved
    # native glyphs, FF padding, and unused tails of bank EF stay protected.
    for _, destination, codes in BATTLE_PACKED_SLOTS:
        for block in range(BATTLE_BLOCK_COUNT):
            for code in codes:
                start = destination + block * BATTLE_PACKED_PITCH + (code - min(codes)) * 16
                allowed_regions.append((start, start + 16))
    # Unedited engine code, font/cache allocators, and audio are hard protected.
    mask = bytearray(ROM_SIZE)
    for start, end in allowed_regions:
        mask[start:end] = b"\x01" * (end - start)
    if any(a != z and not mask[i] for i, (a, z) in enumerate(zip(base, output, strict=True))):
        raise ValueError("Build changed bytes outside the approved translation regions")
    changed_without_checksum = sum(old != new for old, new in zip(base, output, strict=True))
    complement = int.from_bytes(base[CHECKSUM_OFFSET : CHECKSUM_OFFSET + 2], "little")
    checksum = int.from_bytes(base[CHECKSUM_OFFSET + 2 : CHECKSUM_OFFSET + 4], "little")
    if changed_without_checksum:
        complement, checksum = update_checksum(output)
    final = bytes(output)
    changed_bytes = sum(old != new for old, new in zip(base, final, strict=True))
    report: dict[str, object] = {
        "status": "pass",
        "base_sha256": sha256(base),
        "output_sha256": sha256(final),
        "blank_project_is_exact_release": changed_bytes == 0,
        "changed_bytes": changed_bytes,
        "changed_messages": changed_messages,
        "changed_byte_lookups": changed_byte,
        "changed_word_lookups": changed_word,
        "changed_menu_overrides": menu_changes,
        "protected_release_bytes_unchanged": True,
        "edited_lookup_copies_synchronized": True,
        "dialogue_storage": {
            "used_bytes_with_bank_padding": selected_end - SCRIPT_START,
            "capacity_bytes": SCRIPT_END - SCRIPT_START,
            "remaining_bytes": SCRIPT_END - selected_end,
        },
        "byte_lookup_storage": {
            "used_bytes": new_byte_end - BYTE_LOOKUP_BASE,
            "capacity_bytes": BYTE_LOOKUP_LIMIT - BYTE_LOOKUP_BASE,
            "remaining_bytes": BYTE_LOOKUP_LIMIT - new_byte_end,
        },
        "word_lookup_storage": {
            "used_bytes": new_word_end - WORD_LOOKUP_BASE,
            "capacity_bytes": WORD_LOOKUP_LIMIT - WORD_LOOKUP_BASE,
            "remaining_bytes": WORD_LOOKUP_LIMIT - new_word_end,
        },
        "item_menu_labels_rebuilt": sum(not r.get("reused_original_art") for r in item_report),
        "battle_item_labels_rebuilt": sum(not r.get("reused_original_art") for r in battle_report),
        "packed_battle_blocks_changed": packed_blocks_changed,
        "packed_battle_caches_synchronized": True,
        "magic_labels_rebuilt": sum(not r.get("reused_original_art") for r in spell_report),
        "status_aliases": {str(index): value for index, value in status_aliases.items()},
        "dialogue_warnings": dialogue_warnings,
        "checksum": f"0x{checksum:04X}",
        "checksum_complement": f"0x{complement:04X}",
        "snes_checksum_valid": (checksum ^ complement == 0xFFFF and sum(final) & 0xFFFF == checksum),
    }
    return final, report


def write_ips(base: bytes, target: bytes, output: Path) -> dict[str, int]:
    if len(target) > 0xFFFFFF:
        raise ValueError("IPS target exceeds the 24-bit address space")
    virtual = (base + b"\x00" * max(0, len(target) - len(base)))[: len(target)]
    payload = bytearray(b"PATCH")
    records = 0
    position = 0
    while position < len(target):
        if virtual[position] == target[position]:
            position += 1
            continue
        start = position
        last_difference = position
        position += 1
        while position < len(target) and position - start < 0xFFFF:
            if virtual[position] != target[position]:
                last_difference = position
            elif position - last_difference > 8:
                break
            position += 1
        end = last_difference + 1
        data = target[start:end]
        payload += start.to_bytes(3, "big") + len(data).to_bytes(2, "big") + data
        position = end
        records += 1
    payload += b"EOF"
    if len(base) != len(target):
        payload += len(target).to_bytes(3, "big")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(payload)
    return {"records": records, "bytes": len(payload), "sha256": sha256(bytes(payload))}


def apply_ips(base: bytes, patch: bytes) -> bytes:
    if not patch.startswith(b"PATCH"):
        raise ValueError("Missing IPS header")
    output = bytearray(base)
    cursor = 5
    while patch[cursor : cursor + 3] != b"EOF":
        offset = int.from_bytes(patch[cursor : cursor + 3], "big")
        size = int.from_bytes(patch[cursor + 3 : cursor + 5], "big")
        cursor += 5
        if size:
            data = patch[cursor : cursor + size]
            cursor += size
        else:
            run = int.from_bytes(patch[cursor : cursor + 2], "big")
            data = patch[cursor + 2 : cursor + 3] * run
            cursor += 3
        end = offset + len(data)
        if end > len(output):
            output.extend(b"\x00" * (end - len(output)))
        output[offset:end] = data
    cursor += 3
    if cursor + 3 == len(patch):
        size = int.from_bytes(patch[cursor : cursor + 3], "big")
        if len(output) < size:
            output.extend(b"\x00" * (size - len(output)))
        else:
            del output[size:]
    return bytes(output)
