#!/usr/bin/env python3
"""Small dependency-free reader for the toolkit's known XLSX table sheets."""

from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


def column_index(reference: str) -> int:
    match = re.match(r"([A-Z]+)", reference)
    if not match:
        raise ValueError(f"Invalid cell reference {reference!r}")
    value = 0
    for character in match.group(1):
        value = value * 26 + ord(character) - 64
    return value - 1


def shared_strings(archive: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    result: list[str] = []
    for item in root.findall(f"{{{MAIN_NS}}}si"):
        result.append("".join(node.text or "" for node in item.iter(f"{{{MAIN_NS}}}t")))
    return result


def sheet_paths(archive: zipfile.ZipFile) -> dict[str, str]:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    targets = {
        item.attrib["Id"]: item.attrib["Target"]
        for item in relationships.findall(f"{{{PKG_REL_NS}}}Relationship")
    }
    result: dict[str, str] = {}
    for sheet in workbook.find(f"{{{MAIN_NS}}}sheets") or ():
        rel_id = sheet.attrib[f"{{{REL_NS}}}id"]
        target = targets[rel_id].lstrip("/")
        if not target.startswith("xl/"):
            target = "xl/" + target
        result[sheet.attrib["name"]] = target
    return result


def cell_text(cell: ET.Element, strings: list[str]) -> str:
    kind = cell.attrib.get("t", "n")
    if kind == "inlineStr":
        return "".join(node.text or "" for node in cell.iter(f"{{{MAIN_NS}}}t"))
    value_node = cell.find(f"{{{MAIN_NS}}}v")
    if value_node is None or value_node.text is None:
        return ""
    value = value_node.text
    if kind == "s":
        return strings[int(value)]
    if kind == "b":
        return "TRUE" if value == "1" else "FALSE"
    return value


def read_sheet(archive: zipfile.ZipFile, path: str, strings: list[str]) -> list[list[str]]:
    root = ET.fromstring(archive.read(path))
    rows: list[list[str]] = []
    for row in root.iter(f"{{{MAIN_NS}}}row"):
        values: dict[int, str] = {}
        for cell in row.findall(f"{{{MAIN_NS}}}c"):
            values[column_index(cell.attrib["r"])] = cell_text(cell, strings)
        if values:
            width = max(values) + 1
            rows.append([values.get(index, "") for index in range(width)])
        else:
            rows.append([])
    return rows


def rows_as_dicts(rows: list[list[str]], sheet_name: str) -> list[dict[str, str]]:
    if not rows:
        raise ValueError(f"Workbook sheet {sheet_name!r} is empty")
    headers = rows[0]
    if not headers or any(not header for header in headers):
        raise ValueError(f"Workbook sheet {sheet_name!r} has an invalid header row")
    result: list[dict[str, str]] = []
    for source in rows[1:]:
        padded = source + [""] * (len(headers) - len(source))
        row = dict(zip(headers, padded[: len(headers)], strict=True))
        if any(value != "" for value in row.values()):
            result.append(row)
    return result


def read_translation_workbook(path: Path) -> dict[str, list[dict[str, str]]]:
    with zipfile.ZipFile(path) as archive:
        strings = shared_strings(archive)
        paths = sheet_paths(archive)
        result: dict[str, list[dict[str, str]]] = {}
        for sheet_name, key in (
            ("Dialogue", "dialogue"),
            ("Lookups", "lookups"),
            ("Menu Text", "menu_text"),
        ):
            if sheet_name not in paths:
                raise ValueError(f"Workbook is missing required sheet {sheet_name!r}")
            result[key] = rows_as_dicts(
                read_sheet(archive, paths[sheet_name], strings), sheet_name
            )
        return result


def read_project(path: Path) -> dict[str, list[dict[str, str]]]:
    if path.suffix.lower() == ".xlsx":
        payload = read_translation_workbook(path)
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Expected a translation project object")
        if payload.get("format") != "LadyStalker-v1.2.9-translation-project-v1":
            if {"base_sha256", "output_sha256", "changed_messages"}.issubset(payload):
                raise ValueError(
                    "This JSON is a build report, not a translation project. "
                    "Open the matching *_project.json file instead."
                )
            raise ValueError("Use the supplied v1.2.9 translation project. Older projects have different reference text.")
    result = {}
    for key, required in (
        ("dialogue", ("message_id", "english_reference", "replacement_text")),
        ("lookups", ("table", "index", "english_reference", "replacement_text")),
        ("menu_text", ("context", "lookup_index", "current_menu_text", "replacement_menu_text")),
    ):
        rows = payload.get(key)
        if not isinstance(rows, list) or not rows:
            raise ValueError(f"Missing {key} rows in translation project")
        for row in rows:
            if not isinstance(row, dict) or any(k not in row for k in required):
                raise ValueError(f"Invalid or older {key} table. Use the supplied v1.2.9 project/workbook.")
            for column in required:
                if column not in ("index", "lookup_index") and not isinstance(row[column], str):
                    raise ValueError(f"{key}/{column} must be text")
        result[key] = rows
    return result


def write_project(path: Path, data: dict[str, list[dict[str, str]]]) -> None:
    payload = {
        "format": "LadyStalker-v1.2.9-translation-project-v1",
        "toolkit_version": "2.1",
        "dialogue": data["dialogue"],
        "lookups": data["lookups"],
        "menu_text": data["menu_text"],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
